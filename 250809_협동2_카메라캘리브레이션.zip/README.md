# Code Descriptions

## `2_3_a_create_data_dirs.py`
```
준석 / 250809

모델 생성을 위한 이미지가 저장될 디렉토리 생성하는 코드

<Result>
    
    my_data/
    ├── train/
    │   ├── images/
    │   └── labels/
    ├── test/
    │   └── images/
    └── valid/
        ├── images/
        └── labels/
```

## `2_3_b_move_image.py`
```
준석 / 250809
  <3줄 요약>
    원본 이미지 디렉터리의 파일들을 무작위로 섞습니다.
    사용자가 지정한 비율(기본값: 학습 70%, 검증 20%, 테스트 10%)에 따라 파일을 세 그룹으로 나눕니다.
    분할된 파일들을 각각 train/images, valid/images, test/images 디렉터리에 복사하여 저장합니다.
```

## `2_3_c_move_labels.py`
```
준석 / 250809
  <3줄 요약>
    특정 이미지(.jpg) 파일 목록을 기준으로 파일 이름과 동일한 .txt 파일을 찾습니다.
    지정된 레이블 원본 디렉터리에서 해당 .txt 파일이 있는지 확인합니다.
    이미지와 이름이 같은 레이블 파일이 존재하면, 이를 목표 레이블 디렉터리로 복사합니다.
```

## `2_4_c_compare_yolo.py`
```
준석 / 250809

    <3줄 요약>
    Ultralytics YOLOv8 모델을 사용하여 GPU에서 이미지의 객체를 감지하고 추적합니다.
    감지된 각 객체에 대해 고유한 추적 ID, 클래스 이름, 신뢰도를 경계 상자와 함께 이미지에 표시합니다.
    처리된 이미지를 화면에 보여주며, 사용자가 q 키나 Ctrl+C를 누르면 프로그램이 종료됩니다.
```

## `2_4_d_yolov8_obj_det_wc.py`
```
준석 / 250809

    <3줄 요약>
    이 프로그램은 YOLO 모델을 이용해 웹캠에서 실시간으로 객체를 감지하고, 그 결과를 화면에 시각화합니다.
    감지된 모든 객체의 위치와 신뢰도 데이터를 CSV, JSON 파일로 저장하며, 객체가 감지된 프레임 이미지를 JPG 파일로 저장합니다.
    웹캠 처리 중 감지된 최대 객체 수와 평균 신뢰도 같은 통계 정보를 별도의 CSV 파일로 기록합니다.
```

## `2_4_h_yolov8_obj_det_thread.py`
```
준석 / 250809
    <3줄 요약>
    이 코드는 YOLOv8 모델과 ROS 2 노드를 결합하여 로봇 카메라의 실시간 이미지 스트림에서 객체를 감지합니다.
    ROS 메시지 수신과 YOLO 추론을 별도의 스레드에서 실행하여 성능 저하 없이 실시간 처리를 가능하게 합니다.
    감지된 객체는 바운딩 박스와 라벨과 함께 화면에 표시되며, 'q' 또는 Ctrl+C로 종료할 수 있습니다.
```

## `2_4_i_yolov8_obj_det_track.py`
```
준석 / 250809
    <3줄 요약>
    ROS 2 노드가 카메라 이미지 토픽을 구독하면, YOLOv8 모델의 track() 기능을 사용하여 이미지 내의 객체를 감지하고 추적합니다.
    추적된 객체들은 각각 고유한 ID를 부여받고, 해당 ID, 클래스 이름, 신뢰도가 경계 상자와 함께 화면에 실시간으로 표시됩니다.
    이 프로그램은 멀티스레딩 없이 단일 ROS 2 콜백 함수 내에서 모든 처리를 수행하며, 'q' 키나 Ctrl+C로 종료할 수 있습니다.
```

## `data_recording.py`
```
준석 / 250809
카메라 칼리브레이션을 위해서 로봇 웹캠으로 이미지 찍는 코드

실행방법

<terminal 1> ros2 launch dsr_bringup2 dsr_bringup2_rviz.launch.py mode:=real host:=192.168.1.100 port:=12345 model:=m0609
<terminal 2> ros2 launch realsense2_camera rs_align_depth_launch.py depth_module.depth_profile:=640x480x30 rgb_camera.color_profile:=640x480x30 initial_reset:=true align_depth.enable:=true enable_rgbd:=true pointcloud.enable:=true

이후 웹캠 화면이 나오면 RGB 화면인지 확인!
캡쳐는 키보드 q키 입력시 현재 디렉토리에 data 디렉토리가 생기고 그 안에 이미지 저장됨

만약 웹캠 화면이 그레이스케일, 즉 회색 화면이라면 아래 방법으로 로봇팔의 웹캠 포트 번호 얻어서 DEVICE_NUMBER 값 수정!

## PC와 연결된 기기들 정보 확인 명령어 - 웹캠이 몇번 포트에 연결되어 있는지 확인가능
v4l2-ctl --list-devices
```

## `test.py`
```
준석 / 250809

본 파일 실행 방법

1. 우분투 터미널 열기 () 터미널을 반으로 나눠 하단의 명령어 하나씩 입력
<terminal 1> ros2 launch dsr_bringup2 dsr_bringup2_rviz.launch.py mode:=real host:=192.168.1.100 port:=12345 model:=m0609
<terminal 2> ros2 service call /dsr01/system/set_robot_node dsr_msgs2/srv/SetRobotMode “robot_node: 0”
<terminal 2> ros2 launch realsense2_camera rs_align_depth_launch.py depth_module.depth_profile:=640x480x30 rgb_camera.color_profile:=640x480x30 initial_reset:=true align_depth.enable:=true enable_rgbd:=true pointcloud.enable:=true

2. 본 코드를 VScode로 연다
3. Ctrl + ` 를 눌러 터미널을 연다
4. export PYTHONPATH=$PYTHONPATH:~/ros2_ws/install/dsr_common2/lib/dsr_common2/imp
   상단의 export를 터미널에 입력!
   이후 VScode로 본 코드 실행!

+) export 부분은 .bashrc에 넣어둬도 됨!



!!!!! 그래서 이 코드가 뭐하는 거야?

로봇팔의 웹캠에서 보이는 특정 부분을 마우스로 클릭하면 해당 부분으로 이동하고 그리퍼 동작하는 코드임!

1. 상단의 실행방법대로 실행하면 카메라 화면이 나옴 -> 로봇팔에 달린 웹캠 화면임
2. 화면의 아무 부분 마우스 왼쪽 버튼 클릭 시 -> 로봇팔이 해당 위치로 이동 그립을 진행
3. 로봇팔은 마우스 클릭된 부분으로 이동하고 해당 부분에서 그리퍼를 작동 -> 이후 홈으로 돌아온 다음 그리퍼를 품
```

## `webcam_cap1.py`
```
준석 / 250809
키보드 C 버튼을 누르면 사진이 찍히는 프로그램

웹캠 포트 확인

만약 오류 난다면 vs코드에서 터미널 연 다음 아래 명령어 입력

v4l2-ctl --list-devices

웹캠이 연결된 포트 번호를 얻어올 수 있음
```

## `webcam_cap2.py`
```
준석 / 250809
하단에 설정한 타이머 간격으로 알아서 사진 찍는 프로그램

웹캠 포트 확인

만약 오류 난다면 vs코드에서 터미널 연 다음 아래 명령어 입력

v4l2-ctl --list-devices

웹캠이 연결된 포트 번호를 얻어올 수 있음
```
