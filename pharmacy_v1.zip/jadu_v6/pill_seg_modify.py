#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pill_seg.py (reworked)
- box_seg.py의 '현재 자세 안정화'와 '픽셀→베이스 좌표 변환' 파이프라인을 그대로 적용
- 그립 방향 Z-down 정규화도 box_seg와 동일 수식 사용
- ROI/세그마스크에서 중심점 및 그립각만 계산하고, 실제 좌표/자세 산출은 공통 유틸로 통일
"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Bool
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import numpy as np
import cv2
import time
from dataclasses import dataclass
from typing import Tuple, Optional

# ===== 로봇 API 불러오기 (Doosan/DSR 등 프로젝트 환경에 맞춰 수정) =====
# TODO: 여러분 프로젝트에서 현재 TCP 포즈를 얻는 API로 교체하세요.
# from dsr_robot import get_current_posx, movej, movel, set_tcp ...
# 본 예시는 의사코드 형태입니다.
class RobotAPI:
    def __init__(self):
        pass
    def get_current_posx(self):
        """
        Returns 6D pose (x,y,z, rx, ry, rz) in BASE frame
        NOTE: 실제 DSR에 맞게 교체. rad/deg 일치 필수.
        """
        # TODO: 실제 구현으로 바꾸세요.
        return [500.0, 0.0, 300.0, 0.0, 180.0*np.pi/180.0, 0.0]  # dummy
    def movel(self, pose_xyzrpy, vel=100, acc=100):
        # TODO: 실제 선형 이동 API
        pass
    def set_tcp(self, tcp):
        # TODO
        pass

# ====== 유틸: 회전행렬/쿼터니언/좌표 변환 ======
def rpy_to_matrix(roll, pitch, yaw):
    cr, sr = np.cos(roll), np.sin(roll)
    cp, sp = np.cos(pitch), np.sin(pitch)
    cy, sy = np.cos(yaw), np.sin(yaw)
    Rz = np.array([[cy,-sy,0],[sy,cy,0],[0,0,1]])
    Ry = np.array([[cp,0,sp],[0,1,0],[-sp,0,cp]])
    Rx = np.array([[1,0,0],[0,cr,-sr],[0,sr,cr]])
    return Rz @ Ry @ Rx

def matrix_to_rpy(R):
    # 숫자적 안정성 고려 간단 구현
    pitch = np.arcsin(-R[2,0])
    roll  = np.arctan2(R[2,1], R[2,2])
    yaw   = np.arctan2(R[1,0], R[0,0])
    return roll, pitch, yaw

def make_t(R, t):
    T = np.eye(4)
    T[:3,:3] = R
    T[:3, 3] = t
    return T

def invert_t(T):
    R = T[:3,:3]
    t = T[:3, 3]
    Tinv = np.eye(4)
    Tinv[:3,:3] = R.T
    Tinv[:3, 3] = -R.T @ t
    return Tinv

# ====== box_seg와 동일 개념의 '현재 자세 안정화' ======
def median_filter(arr, axis=0):
    return np.median(np.stack(arr, axis=0), axis=axis)

def mad_based_outlier_mask(samples, thresh=3.5):
    """
    Median Absolute Deviation 기반 이상치 마스크
    samples: (N, D)
    """
    med = np.median(samples, axis=0)
    mad = np.median(np.abs(samples - med), axis=0) + 1e-9
    z = 0.6745 * np.abs(samples - med) / mad
    mask = (np.max(z, axis=1) < thresh)
    return mask

def get_stable_tcp(robot: RobotAPI, n_samples=10, dt=0.01, use_median=True) -> np.ndarray:
    """
    box_seg 스타일: 다회 샘플링 → MAD 이상치 제거 → 중앙값(또는 평균)
    반환: (6,) [x,y,z, rx,ry,rz] (베이스 좌표계)
    """
    samples = []
    for _ in range(n_samples):
        p = np.array(robot.get_current_posx(), dtype=float)  # (6,)
        samples.append(p)
        time.sleep(dt)
    samples = np.stack(samples, axis=0)  # (N,6)

    mask = mad_based_outlier_mask(samples, thresh=3.5)
    filtered = samples[mask] if np.any(mask) else samples

    if use_median:
        pose = np.median(filtered, axis=0)
    else:
        pose = np.mean(filtered, axis=0)
    return pose  # (6,)

# ====== box_seg와 동일한 픽셀→베이스 좌표 변환 (핵심) ======
@dataclass
class CameraModel:
    K: np.ndarray  # (3,3)
    dist: Optional[np.ndarray] = None

def pixel_to_cam(u, v, depth, K: np.ndarray) -> np.ndarray:
    fx, fy = K[0,0], K[1,1]
    cx, cy = K[0,2], K[1,2]
    X = (u - cx) * depth / fx
    Y = (v - cy) * depth / fy
    Z = depth
    return np.array([X, Y, Z], dtype=float)

def pixel_to_base(u, v, depth, K: np.ndarray,
                  T_base_tcp: np.ndarray, T_tcp_cam: np.ndarray) -> np.ndarray:
    Pc = pixel_to_cam(u, v, depth, K)  # cam frame
    Tc = make_t(np.eye(3), Pc)
    T_base_cam = T_base_tcp @ T_tcp_cam
    Pw = (T_base_cam @ Tc)[:3,3]      # world/base frame position
    return Pw

# ====== Z-Down 정렬(박스와 동일 수식) ======
def make_z_down_pose(yaw_rad: float, pos_xyz: np.ndarray) -> np.ndarray:
    """
    Z축을 아래(-Z)로 향하게 하고 yaw만 대상 각도에 맞춤.
    roll=pi, pitch=0, yaw=yaw_rad 형태로 구성 (예시)
    """
    roll = np.pi    # Z-down
    pitch = 0.0
    yaw = yaw_rad
    R = rpy_to_matrix(roll, pitch, yaw)
    T = make_t(R, pos_xyz)
    return T

# ====== 마스크에서 그립 중심/각도 산출 (pill 고유 파트) ======
def mask_center_and_angle(mask: np.ndarray) -> Tuple[Tuple[int,int], float]:
    """
    세그 마스크로부터 중심점과 주축 각도(라디안) 산출.
    - 중심: 모멘트
    - 각도: PCA 또는 minAreaRect 각도 사용
    """
    ys, xs = np.where(mask > 0)
    if len(xs) < 10:
        return (0,0), 0.0

    cx = int(np.mean(xs))
    cy = int(np.mean(ys))

    pts = np.column_stack([xs, ys]).astype(np.float32)
    if pts.shape[0] >= 5:
        (x,y),(w,h),theta_deg = cv2.minAreaRect(pts)
        # OpenCV 각도 규약 보정
        theta = np.deg2rad(theta_deg)
    else:
        theta = 0.0
    return (cx, cy), float(theta)

# ====== 노드 구현 ======
class PillSegNode(Node):
    def __init__(self):
        super().__init__('rokey_pill_seg_node')
        self.bridge = CvBridge()
        self.robot = RobotAPI()

        # --- 파라미터 (여러분 환경으로 조정) ---
        self.declare_parameter('model_path', 'model/my_best_pill_2.pt')  # TODO
        self.declare_parameter('camera_matrix', [  # 예시 K
            615.0, 0.0, 320.0,
            0.0, 615.0, 240.0,
            0.0,   0.0,   1.0
        ])
        self.declare_parameter('T_gripper2camera_npy', 'T_gripper2camera.npy')  # TODO
        self.declare_parameter('depth_scale', 0.001)  # mm→m 등 스케일

        K_list = self.get_parameter('camera_matrix').value
        self.K = np.array(K_list, dtype=float).reshape(3,3)

        # TCP→Camera transform (box_seg와 동일 파일 사용)
        try:
            T_tcp_cam_np = np.load(self.get_parameter('T_gripper2camera_npy').value)
            if T_tcp_cam_np.shape == (4,4):
                self.T_tcp_cam = T_tcp_cam_np
            else:
                self.get_logger().warn("T_gripper2camera.npy shape invalid. Using identity.")
                self.T_tcp_cam = np.eye(4)
        except Exception as e:
            self.get_logger().warn(f"Load T_gripper2camera failed: {e}. Using identity.")
            self.T_tcp_cam = np.eye(4)

        # 세그 시작/완료 토픽 (box_seg와 맞춤)
        self.start_sub = self.create_subscription(String, '/seg_start', self.on_seg_start, 10)
        self.done_pub  = self.create_publisher(Bool, '/pill_seg_done', 10)

        # 카메라 토픽 (필요시)
        # self.rgb_sub = self.create_subscription(Image, '/camera/color/image_raw', self.on_rgb, 10)
        # self.depth_sub = self.create_subscription(Image, '/camera/depth/image_raw', self.on_depth, 10)

        self.rgb = None
        self.depth = None

        # YOLO/세그 모델 로드 (여러분 환경)
        self.model = None
        try:
            from ultralytics import YOLO
            self.model = YOLO(self.get_parameter('model_path').value)
            self.get_logger().info("YOLO model loaded.")
        except Exception as e:
            self.get_logger().warn(f"YOLO load failed: {e}. Segmentation will be skipped.")

    def on_seg_start(self, msg: String):
        target_name = msg.data.strip()
        self.get_logger().info(f"/seg_start 수신 - 타겟: {target_name}")

        # 1) box_seg와 동일: 안정화된 현재 TCP 포즈 추출
        pose6 = get_stable_tcp(self.robot, n_samples=12, dt=0.01, use_median=True)  # (6,)
        x,y,z, rx,ry,rz = pose6
        R_base_tcp = rpy_to_matrix(rx, ry, rz)
        T_base_tcp = make_t(R_base_tcp, np.array([x,y,z], dtype=float))

        # 2) 이미지 획득 & 세그 실행 (여러분 환경에 맞게 교체)
        frame_bgr, depth_map = self.capture_once()
        if frame_bgr is None or depth_map is None:
            self.get_logger().error("카메라 프레임/깊이 획득 실패")
            self.done_pub.publish(Bool(data=False))
            return

        mask, (u,v), theta = self.run_seg_and_pick(frame_bgr, target_name)
        if mask is None:
            self.get_logger().warn("타겟 세그 실패")
            self.done_pub.publish(Bool(data=False))
            return

        # 3) 픽셀→베이스 좌표 변환(box_seg 동일)
        #    깊이는 중심점 주변 3x3 중앙값 사용(노이즈 완화) + depth_scale 반영
        depth_val = self.sample_depth(depth_map, u, v)
        depth_m = float(depth_val) * float(self.get_parameter('depth_scale').value)
        Pw = pixel_to_base(u, v, depth_m, self.K, T_base_tcp, self.T_tcp_cam)  # (3,)

        # 4) Z-down 정렬(box_seg 동일 수식)
        T_target = make_z_down_pose(theta, Pw)

        # 5) 접근-그립-리트랙트(의사코드: 여러분 로봇 API로 교체)
        self.execute_pick_sequence(T_target)

        # 완료 알림
        self.done_pub.publish(Bool(data=True))
        self.get_logger().info("pill_seg 완료")

    # === 카메라 단발 캡처 (예시) ===
    def capture_once(self):
        # TODO: 실제론 ROS 이미지 버퍼/최근 프레임 사용 권장
        try:
            cap = cv2.VideoCapture(0)
            ok, bgr = cap.read()
            cap.release()
            if not ok:
                return None, None
            # depth는 예시: 실제 depth 토픽/장치에서 받도록 교체
            depth = np.full((bgr.shape[0], bgr.shape[1]), 800.0, dtype=np.float32)  # mm dummy
            return bgr, depth
        except Exception:
            return None, None

    def run_seg_and_pick(self, bgr, target_name):
        if self.model is None:
            return None, (0,0), 0.0
        # YOLO 세그 실행
        res = self.model(bgr, verbose=False, conf=0.5, task='segment')
        if len(res) == 0 or len(res[0].masks) == 0:
            return None, (0,0), 0.0

        # 가장 큰 마스크 1개 선택(예시)
        masks = res[0].masks.data.cpu().numpy().astype(np.uint8)  # (N,H,W)
        areas = [np.count_nonzero(m) for m in masks]
        idx = int(np.argmax(areas))
        mask = masks[idx]*255

        (cx, cy), theta = mask_center_and_angle(mask)
        return mask, (cx, cy), theta

    def sample_depth(self, depth_map, u, v, ksize=3):
        h, w = depth_map.shape[:2]
        u0 = max(0, u - ksize//2); u1 = min(w, u + ksize//2 + 1)
        v0 = max(0, v - ksize//2); v1 = min(h, v + ksize//2 + 1)
        patch = depth_map[v0:v1, u0:u1].astype(np.float32)
        patch = patch[np.isfinite(patch)]
        if patch.size == 0:
            return float('nan')
        return float(np.median(patch))

    def execute_pick_sequence(self, T_target: np.ndarray):
        """
        box_seg와 동일한 이동 시퀀스를 사용하세요.
        여기서는 의사코드로 표기.
        """
        # 접근 위치: z + offset
        approach = T_target.copy()
        approach[2,3] += 0.05  # 5cm 위 (예시, 단위 m 가정)
        # 그립 위치
        grasp = T_target.copy()
        # 리트랙트
        retract = T_target.copy()
        retract[2,3] += 0.10

        # TODO: 여러분 로봇 API로 교체 (선형/조인트 이동, 속도/가속, 그리퍼 제어 등)
        # self.robot.movel(pose_from_T(approach))
        # self.robot.movel(pose_from_T(grasp))
        # close_gripper()
        # self.robot.movel(pose_from_T(retract))
        pass


def main(args=None):
    rclpy.init(args=args)
    node = PillSegNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
