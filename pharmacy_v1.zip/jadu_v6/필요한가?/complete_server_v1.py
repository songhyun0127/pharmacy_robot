# medicine_server.py (switch-case 분기/실행 포함 버전)

import os
import sys
import subprocess
import rclpy
from rclpy.node import Node
from pharmacy_interface.srv import MediCine

class MedicineServerNode(Node):
    """
    클라이언트로부터 약품 정보를 받아 '알약' 또는 '약상자' 픽킹 스크립트를 실행하는 서비스 서버.
    - 현재 시나리오: '알약만' 또는 '약상자만' 집고 종료
    - 향후 시나리오: 둘 다 True면 '알약 -> 약상자' 순서로 실행(주석 처리된 부분 참고)
    """

    def __init__(self):
        super().__init__('medicine_server_node')
        self.srv = self.create_service(MediCine, 'order_medicines', self.handle_request)
        self.get_logger().info('약품 주문 서비스 서버가 준비되었습니다.')

        # 파일 경로(같은 패키지 디렉토리에 두었을 때 기준)
        self.pkg_dir = os.path.dirname(os.path.abspath(__file__))
        self.seg_script = os.path.join(self.pkg_dir, 'seg_test1.py')       # 알약 픽킹
        self.box_script = os.path.join(self.pkg_dir, 'yolo_move_cp1.py')   # 약상자 픽킹

        # 분류 그룹: 알약 그룹 / 약상자 그룹
        # - 현재 STT_QR_connect.py 상 논리: penzal/sky/tg/zaide(처방 필요)는 항상 False가 들어옴
        # - OTC(비처방) 3종: famotidine/somnifacient/allergy 가 True 후보 => 약상자 로직과 연결
        self.PILL_KEYS = {'penzal', 'sky', 'tg', 'zaide'}
        self.BOX_KEYS  = {'famotidine', 'somnifacient', 'allergy'}

    def decide_pick_mode(self, request) -> str:
        """
        현재 요청을 보고 'pill' / 'box' / 'none' 중 하나를 판정.
        - 현재 시나리오: pill만 True면 'pill', box만 True면 'box'
        - 향후(둘 다 True)엔 pill->box 순서로 실행할 예정(아래 handle_request 주석 참고)
        """
        pill_true = any(getattr(request, k, False) for k in self.PILL_KEYS)
        box_true  = any(getattr(request, k, False) for k in self.BOX_KEYS)

        if pill_true and not box_true:
            return 'pill'
        elif box_true and not pill_true:
            return 'box'
        elif not pill_true and not box_true:
            return 'none'
        else:
            # 둘 다 True인 미래 시나리오
            return 'both'

    def run_script(self, script_path: str) -> int:
        """
        개별 픽킹 스크립트를 동기 실행합니다.
        - 반환값: 프로세스 returncode (0=정상)
        """
        if not os.path.exists(script_path):
            self.get_logger().error(f"실행 파일을 찾을 수 없습니다: {script_path}")
            return -1

        self.get_logger().info(f"실행 시작: {script_path}")
        try:
            # 같은 파이썬으로 실행(ROS2 환경 유지)
            result = subprocess.run([sys.executable, script_path], check=False)
            rc = result.returncode
            if rc == 0:
                self.get_logger().info(f"실행 완료(성공): {script_path}")
            else:
                self.get_logger().error(f"실행 종료(코드={rc}): {script_path}")
            return rc
        except Exception as e:
            self.get_logger().error(f"실행 중 예외 발생: {e}")
            return -1

    def handle_request(self, request, response):
        """서비스 요청을 처리하는 콜백 함수."""
        self.get_logger().info('새로운 약품 주문 요청을 받았습니다:')

        # 1) 수신 상태 로그
        self.get_logger().info('--- 요청된 약품 상태 ---')
        self.get_logger().info(f"  - Penzal: {request.penzal}")
        self.get_logger().info(f"  - Sky: {request.sky}")
        self.get_logger().info(f"  - Tg: {request.tg}")
        self.get_logger().info(f"  - Zaide: {request.zaide}")
        self.get_logger().info(f"  - Famotidine: {request.famotidine}")
        self.get_logger().info(f"  - Somnifacient: {request.somnifacient}")
        self.get_logger().info(f"  - Allergy: {request.allergy}")

        # 2) 응답(요청 echo) – 기존 동작 유지
        response.penzal = request.penzal
        response.sky = request.sky
        response.tg = request.tg
        response.zaide = request.zaide
        response.famotidine = request.famotidine
        response.somnifacient = request.somnifacient
        response.allergy = request.allergy

        # 3) 무엇을 집어야 하는지 결정
        mode = self.decide_pick_mode(request)
        self.get_logger().info(f"[결정] 픽킹 모드: {mode}")

        # 4) switch-case (Python 3.10+ match-case)
       # --- pill 모드 내부 로직 확장 ---
        match mode:
            case 'pill':
                # 어떤 알약을 집어야 하는지 세부 결정
                if request.penzal:
                    self.get_logger().info("[알약 선택] Penzal 픽킹 실행")
                    # TODO: Penzal 전용 픽킹 동작 작성 (웨이포인트 또는 seg_test1.py 호출)
                    # 예: self.run_script(self.seg_script, extra_args=["penzal"])
                elif request.sky:
                    self.get_logger().info("[알약 선택] Sky 픽킹 실행")
                    # TODO: Sky 전용 픽킹 동작 작성
                elif request.tg:
                    self.get_logger().info("[알약 선택] Tg 픽킹 실행")
                    # TODO: Tg 전용 픽킹 동작 작성
                elif request.zaide:
                    self.get_logger().info("[알약 선택] Zaide 픽킹 실행")
                    # TODO: Zaide 전용 픽킹 동작 작성
                else:
                    self.get_logger().warn("알약 플래그가 True인 항목이 없습니다.")

            case 'box':
                # 약상자만 집고 종료
                rc = self.run_script(self.box_script)
                if rc != 0:
                    self.get_logger().error("약상자 픽킹에 실패했습니다.")
            case 'both':
                # (미래 시나리오) 둘 다 True라면 고정 순서: 알약 -> 약상자
                # 현재 요구사항에선 실행되지 않지만, 향후 확장 대비 코드만 남겨둠
                self.get_logger().info("둘 다 요청됨: 알약 → 약상자 순으로 실행합니다.")
                rc1 = self.run_script(self.seg_script)
                if rc1 == 0:
                    rc2 = self.run_script(self.box_script)
                    if rc2 != 0:
                        self.get_logger().error("약상자 픽킹에 실패했습니다.")
                else:
                    self.get_logger().error("알약 픽킹에 실패하여 약상자 단계는 생략합니다.")
            case _:
                self.get_logger().warn("집을 대상이 없습니다. (pill/box 모두 False)")

        # === TODO ==============================================
        # 여기서부터 추가 로봇 동작 코드를 작성하세요.
        # 예) 픽킹 완료 후 특정 웨이포인트로 이동, UI/로그 업데이트, 다음 작업 대기 등
        # ========================================================

        return response

def main(args=None):
    rclpy.init(args=args)
    node = MedicineServerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
