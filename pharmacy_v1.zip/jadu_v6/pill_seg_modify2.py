#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pill_seg.py (reworked)
- box_seg.py의 '좌표 산출 파이프라인'을 그대로 이식: 마스크→PCA→깊이 메디안→px2cam→cam2gripper→(opt)gripper2base
- 그리퍼/DR_init/경로/상수는 기존 pill_seg 블록을 그대로 사용
- Z-down 정규화(그립 축일치) 로직 포함
"""

import os
os.environ["CUDA_VISIBLE_DEVICES"] = ""  # GPU 비활성화 (필요 시 제거)

import cv2
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from scipy.spatial.transform import Rotation as R
from ultralytics import YOLO
import time
import numpy as np
from pathlib import Path

# ======== pill_seg 고정 블록 (그대로 유지) ========
from .realsense import ImgNode
from .onrobot import RG
import DR_init

#------path------
tgripper_file = (Path.home()/"ros2_ws"/"src"/"DoosanBootcamp3rd"/"dsr_rokey"/"rokey"/"rokey"/"basic"/"config"/"T_gripper2camera.npy")
yolo_pill_model_file = (Path.home()/"ros2_ws"/"src"/"DoosanBootcamp3rd"/"dsr_rokey"/"rokey"/"rokey"/"basic"/"config"/"my_best_pill_2.pt")
#------path------

# 로봇 및 그리퍼 설정
ROBOT_ID = "dsr01"
ROBOT_MODEL = "m0609"
VELOCITY, ACC = 60, 60

DR_init.__dsr__id = ROBOT_ID
DR_init.__dsr__model = ROBOT_MODEL

GRIPPER_NAME = "rg2"
TOOLCHARGER_IP = "192.168.1.1"
TOOLCHARGER_PORT = "502"
# ================================================


def load_T_gripper2camera(path: Path) -> np.ndarray:
    if not path.exists():
        raise FileNotFoundError(f"T_gripper2camera 파일을 찾을 수 없음: {path}")
    T = np.load(str(path))
    if T.shape != (4, 4):
        raise ValueError("T_gripper2camera는 4x4 동차변환이어야 합니다.")
    return T


def se3(Rm: np.ndarray, t: np.ndarray) -> np.ndarray:
    """R(3x3), t(3,) -> T(4x4)"""
    T = np.eye(4, dtype=float)
    T[:3, :3] = Rm
    T[:3, 3] = t.reshape(3)
    return T


def pose_to_T(pose_xyz_rpy: np.ndarray) -> np.ndarray:
    """
    (x,y,z, rx,ry,rz)[m,rad] -> T(4x4)
    - DR SDK의 posx 형식을 가정 (박스 코드 동일 가정)
    """
    x, y, z, rx, ry, rz = pose_xyz_rpy.tolist()
    Rm = R.from_rotvec([rx, ry, rz]).as_matrix()
    return se3(Rm, np.array([x, y, z], dtype=float))


def robust_median_depth(depth_img: np.ndarray, u: int, v: int, k: int = 1) -> float:
    """
    중심 (u,v) 주변 (2k+1)^2 픽셀의 메디안 깊이. NaN 및 0 방어.
    """
    h, w = depth_img.shape[:2]
    u0, v0 = max(0, u - k), max(0, v - k)
    u1, v1 = min(w, u + k + 1), min(h, v + k + 1)
    patch = depth_img[v0:v1, u0:u1].astype(np.float32)
    patch = patch[np.isfinite(patch)]
    patch = patch[patch > 0.0]
    if patch.size == 0:
        return float("nan")
    return float(np.median(patch))


def mask_centroid_and_angle(mask: np.ndarray):
    """
    이진 마스크에서 중심점(u,v)과 주축 각도(rad)를 PCA로 산출 (box_seg 스타일).
    최소 면적/윤곽 검사 포함.
    """
    cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cnts:
        return None, None

    # 가장 큰 컨투어 사용(잡음 방어)
    c = max(cnts, key=cv2.contourArea)
    area = cv2.contourArea(c)
    if area < 100:  # 너무 작은 마스크는 무시
        return None, None

    M = cv2.moments(c)
    if abs(M["m00"]) < 1e-6:
        return None, None
    u = int(M["m10"] / M["m00"])
    v = int(M["m01"] / M["m00"])

    # PCA로 주축 각 계산
    data = c.reshape(-1, 2).astype(np.float32)
    mean, eigenvectors = cv2.PCACompute(data, mean=None, maxComponents=2)
    major = eigenvectors[0]  # 주축
    # 이미지 좌표→u 오른쪽 +, v 아래 +, 각도는 u축(+x_img) 기준 반시계(rad)로 정의
    angle = float(np.arctan2(major[1], major[0]))
    return (u, v), angle


def pixel_to_camera(u: int, v: int, depth_m: float, fx: float, fy: float, cx: float, cy: float):
    """
    픽셀(u,v)+깊이[m] -> 카메라 좌표계[m] (x,y,z)
    x = (u-cx)*z/fx, y=(v-cy)*z/fy, z=depth
    """
    x = (u - cx) * depth_m / fx
    y = (v - cy) * depth_m / fy
    z = depth_m
    return np.array([x, y, z], dtype=float)


def z_down_align_from_pca(pca_angle_rad: float) -> np.ndarray:
    """
    Z-down(그립 z축이 세계-베이스 기준 아래를 향하도록) 정규화 회전.
    - box_seg의 'z축 아래 정규화' 수식을 그대로 개념 반영:
      1) 그립 z축을 -Z로 향하게(Rx(π) 등가) 한 뒤
      2) 물체 주축(pca_angle)을 yaw에 반영해 평행 그립 정렬
    - 결과: R_gripper(3x3). (필요시 추가 오프셋 각도 적용)
    """
    # 기본적으로 z-down: Rx(pi)
    Rzdown = R.from_euler("x", np.pi).as_matrix()
    # 주축 각도를 yaw에 반영 (z축 회전)
    R_yaw = R.from_euler("z", pca_angle_rad).as_matrix()
    return R_yaw @ Rzdown


class PillSegNode(Node):
    def __init__(self):
        super().__init__("rokey_pill_seg_node")
        self.get_logger().info("PillSegNode 초기화...")

        # === Realsense 노드(캠/깊이/내부파라미터) ===
        self.imgnode = ImgNode()  # 프로젝트의 기존 구현 사용
        # imgnode는 아래 속성을 제공한다고 가정: .rgb (H×W×3), .depth (H×W float or uint16), .K(dict)
        # K = {"fx":..., "fy":..., "cx":..., "cy":..., "scale":...}

        # === YOLO 모델 ===
        self.model = YOLO(str(yolo_pill_model_file))

        # === 좌표 변환 행렬 ===
        self.T_g2c = load_T_gripper2camera(tgripper_file)   # (gripper←camera)
        self.T_c2g = np.linalg.inv(self.T_g2c)               # (camera←gripper)^{-1} = (gripper←camera)

        # === 필터 상태 ===
        self.pos_ma = None  # 이동평균 필터용 (3,)
        self.ang_ma = None  # 이동평균 필터용 (rad)
        self.alpha = 0.4    # EMA 계수

        # === 그리퍼 ===
        self.rg = RG(GRIPPER_NAME, TOOLCHARGER_IP, TOOLCHARGER_PORT)

        # === 토픽 ===
        self.sub_start = self.create_subscription(String, "/seg_start", self.on_seg_start, 10)
        self.pub_done  = self.create_publisher(String, "/seg_done", 10)

        self.get_logger().info("초기화 완료. /seg_start 대기 중...")

    # ---------- 유틸 ----------
    def ema(self, prev, curr):
        if prev is None:
            return curr
        return (1 - self.alpha) * prev + self.alpha * curr

    # ---------- 콜백 ----------
    def on_seg_start(self, msg: String):
        target_name = msg.data.strip() if msg and msg.data else ""
        self.get_logger().info(f"/seg_start 수신 - 타겟: {target_name or '(미지정)'}")

        # 1) 최신 이미지/깊이 얻기
        rgb = self.imgnode.rgb.copy()
        depth = self.imgnode.depth.copy()
        if rgb is None or depth is None:
            self.get_logger().error("이미지 또는 깊이 프레임이 유효하지 않습니다.")
            return

        H, W = rgb.shape[:2]
        Kd = self.imgnode.K  # {'fx','fy','cx','cy','scale'}
        fx, fy, cx, cy = float(Kd["fx"]), float(Kd["fy"]), float(Kd["cx"]), float(Kd["cy"])
        dscale = float(Kd.get("scale", 0.001))  # 깊이 단위 스케일 (예: mm->m)

        # 2) YOLO 세그
        t0 = time.time()
        results = self.model.predict(source=rgb, imgsz=max(H, W), verbose=False)
        infer_t = (time.time() - t0) * 1000
        self.get_logger().info(f"YOLO 추론 {infer_t:.1f} ms")

        if len(results) == 0 or len(results[0].masks) == 0:
            self.get_logger().warn("세그멘테이션 결과 없음")
            return

        # pill 후보 중 가장 큰 마스크 선택 (box_seg와 동일 전략)
        masks = results[0].masks.data.cpu().numpy().astype(np.uint8)  # (N, H, W)
        best = None
        best_area = 0
        for m in masks:
            area = int(m.sum())
            if area > best_area:
                best_area = area
                best = m

        if best is None or best_area < 100:
            self.get_logger().warn("유효한 마스크가 없습니다.")
            return

        mask = (best * 255).astype(np.uint8)
        center, pca_angle = mask_centroid_and_angle(mask)
        if center is None:
            self.get_logger().warn("마스크에서 중심/각도 산출 실패")
            return
        u, v = center

        # 3) 깊이(미터) 추출 - 3×3 메디안
        depth_raw = depth
        if depth_raw.dtype != np.float32 and depth_raw.dtype != np.float64:
            depth_m = robust_median_depth(depth_raw, u, v, k=1) * dscale
        else:
            depth_m = robust_median_depth(depth_raw, u, v, k=1)

        if not np.isfinite(depth_m) or depth_m <= 0.0 or depth_m > 2.0:
            self.get_logger().warn(f"깊이 비정상: {depth_m}")
            return

        # 4) 픽셀 -> 카메라 좌표
        p_cam = pixel_to_camera(u, v, depth_m, fx, fy, cx, cy)  # [x,y,z] in camera(m)

        # 5) Z-down + 주축 정렬(그립 회전)
        R_g = z_down_align_from_pca(pca_angle)  # 그립 회전(3x3)

        # 6) 카메라→그리퍼 좌표계 변환 (box_seg의 동일 수식)
        #    p_g = R_g * p_cam + t_g  (여기선 T_c2g를 이용)
        p_cam_h = np.r_[p_cam, 1.0]
        p_g_h = self.T_c2g @ p_cam_h
        p_g = p_g_h[:3]

        # 이동평균(EMA)로 좌표/각도 안정화
        self.pos_ma = self.ema(self.pos_ma, p_g)
        self.ang_ma = float(self.ema(np.array([self.ang_ma])[0] if self.ang_ma is not None else None, np.array([pca_angle])))

        p_g_use = self.pos_ma if self.pos_ma is not None else p_g
        yaw_use = self.ang_ma if self.ang_ma is not None else pca_angle

        self.get_logger().info(f"[GRIPPER-LOCAL] pos(m)={p_g_use}, yaw(rad)={yaw_use:.3f}")

        # 7) (옵션) 현재 TCP(그리퍼→베이스)로 base 좌표 변환
        p_b_use, rpy_b_use = None, None
        try:
            # DR SDK: get_current_posx() -> [x,y,z,rx,ry,rz]
            tcp_posx = np.array(DR_init.get_current_posx())  # 프로젝트 API에 맞게 이미 사용중일 것
            T_b2g = pose_to_T(tcp_posx)   # base←gripper (TCP Pose)
            p_b_h = T_b2g @ np.r_[p_g_use, 1.0]
            p_b = p_b_h[:3]
            # 회전은 Z-down 정규화 R_g를 TCP에 합성 (간단히 yaw만 반영하는 예)
            R_tcp = R.from_rotvec(tcp_posx[3:6]).as_matrix()
            R_total = R_tcp @ R_g
            rpy_b_use = R.from_matrix(R_total).as_euler("xyz")
            p_b_use = p_b
            self.get_logger().info(f"[BASE] pos(m)={p_b_use}, rpy(rad)={rpy_b_use}")
        except Exception as e:
            self.get_logger().warn(f"베이스 변환 건너뜀(get_current_posx 미지원?) - {e}")

        # 8) 그리퍼 제어 & 피킹(여긴 기존 pill_seg 스타일을 유지; 실제 이동은 프로젝트 코드에 맞춰 연결)
        try:
            # 예: RG 사용 (프로젝트에 맞게 오픈/클로즈만 시연)
            self.rg.open()
            time.sleep(0.2)
            # 여기에서 p_b_use 또는 p_g_use로 이동 명령을 호출 (movel/movej 등)
            # 예시) DR_init.movel([...])  # 프로젝트 DR API에 맞게 채워넣기
            # 그립
            self.rg.close()
            time.sleep(0.2)
        except Exception as e:
            self.get_logger().error(f"그리퍼 동작 오류: {e}")

        # 9) 완료 알림
        self.pub_done.publish(String(data="pill_done"))
        self.get_logger().info("Pill segmentation & pose compute 완료 → pill_done 발행")

def main(args=None):
    rclpy.init(args=args)
    node = rclpy.create_node("dummy_init", namespace=ROBOT_ID)
    DR_init.__dsr__node = node

    from DSR_ROBOT2 import get_current_posx, movej, movel, wait
    from DR_common2 import posx, posj

    seg_node = PillSegNode(posx, posj, movej, movel, get_current_posx, wait)

    try:
        rclpy.spin(seg_node)
    except KeyboardInterrupt:
        pass
    finally:
        seg_node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
