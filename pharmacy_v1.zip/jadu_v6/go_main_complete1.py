# go_main.py — stable import order (move.py 스타일) 적용

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from pathlib import Path
import time

# ----------------- 환경 설정 -----------------
ROBOT_ID = "dsr01"
ROBOT_MODEL = "m0609"
VELOCITY, ACC = 30, 30

WAYPOINT_FILE = (Path.home()/"ros2_ws"/"src"/"DoosanBootcamp3rd"/"dsr_rokey"/
                 "rokey"/"rokey"/"basic"/"config"/"waypoint.json")

LIST_TOPIC = ['/seg_start', '/box_start']
# --------------------------------------------


class GoBoxNode(Node):
    """이 노드는 토픽을 받아 시퀀스를 실행한다.
       DSR 함수/유틸은 생성 시 의존성 주입으로 받아 사용한다(임포트 재시도 방지)."""
    def __init__(self,
                 movej, movel, check_force_condition, DR_AXIS_Z,
                 posx, posj,
                 WaypointManager,
                 drug_info, execute_from_key, current_move, current_move_two):
        super().__init__('go_box_node', namespace=ROBOT_ID)

        # DSR/유틸 함수 보관
        self._movej = movej
        self._movel = movel
        self._check_force_condition = check_force_condition
        self._DR_AXIS_Z = DR_AXIS_Z
        self._posx = posx
        self._posj = posj
        self._WaypointManager = WaypointManager
        self._drug_info = drug_info
        self._execute_from_key = execute_from_key
        self._current_move = current_move
        self._current_move_two = current_move_two

        # 상태
        self.seg_done_flag = False
        self.box_done_flag = False
        self.running = False
        self.MD_NAME = ""

        # pub/sub
        self.seg_pub = self.create_publisher(String, LIST_TOPIC[0], 10)
        self.box_pub = self.create_publisher(String, LIST_TOPIC[1], 10)
        self.create_subscription(String, '/seg_done', self.seg_done_cb, 10)
        self.create_subscription(String, '/box_done', self.box_done_cb, 10)
        self.create_subscription(String, '/go_main', self.md_name_cb, 10)

    # ---------- 콜백 & 동기 대기 ----------
    def seg_done_cb(self, msg: String):
        if msg.data.strip().lower() == "done":
            self.get_logger().info("pill_seg 완료 수신")
            self.seg_done_flag = True

    def wait_for_seg_done(self):
        self.seg_done_flag = False
        while rclpy.ok() and not self.seg_done_flag:
            rclpy.spin_once(self, timeout_sec=0.1)

    def box_done_cb(self, msg: String):
        if msg.data.strip().lower() == "done":
            self.get_logger().info("box_seg 완료 수신")
            self.box_done_flag = True

    def wait_for_box_done(self):
        self.box_done_flag = False
        while rclpy.ok() and not self.box_done_flag:
            rclpy.spin_once(self, timeout_sec=0.1)

    # ---------- 퍼블리시 ----------
    def run_pill(self, info: str):
        self.seg_pub.publish(String(data=info))
        self.get_logger().info(f"pill_seg 시작: {info}")
        self.wait_for_seg_done()

    def run_box(self, info: str):
        self.box_pub.publish(String(data=info))
        self.get_logger().info(f"box_seg 시작: {info}")
        self.wait_for_box_done()

    # ---------- /go_main 수신 → 실행 ----------
    def md_name_cb(self, msg: String):
        name = msg.data.strip()
        self.get_logger().info(f"/go_main 수신: '{name}'")

        if not name:
            self.get_logger().warn("빈 약 이름. 생략.")
            return
        if self.running:
            self.get_logger().warn("이미 동작 중. 새로운 요청 무시.")
            return

        self.running = True
        try:
            self.execute_flow(name)
        except Exception as e:
            self.get_logger().error(f"동작 예외: {e}")
        finally:
            self.running = False

    # ---------- 실제 시퀀스 ----------
    def execute_flow(self, name: str):
        # 유틸 준비
        wp = self._WaypointManager(WAYPOINT_FILE)
        home = wp.get_pos("home")
        client = wp.get_pos("client")

        # 홈 이동
        self.get_logger().info("홈 포즈 이동")
        self._movej(home, vel=VELOCITY, acc=ACC)

        # 약 정보 조회
        self.get_logger().info(f"약 정보 조회: {name}")
        info = self._drug_info(name)
        if not info:
            self.get_logger().error("해당 약 이름 waypoint 없음")
            return

        if info['group'] == 'list_drug':
            #### 여기 전부를 box 처럼 노드 하나로 처리했으면 좋겠음
            self._execute_from_key(info['pos'], step="pick")
            # node.run_pill(name)
            self._execute_from_key(info['pos'], step="place")
            self._movej(home, vel=VELOCITY, acc=ACC)
            # 예시 후속 동작
            # 알약 집는 동작 추가

        elif info['group'] == 'list_box':
            self.get_logger().info("박스 동작 테스트")
            self.run_box(name)

        # 고객 봉투 상부로 이동 후 내려놓기
        self.get_logger().info("봉투로")
        self._movel(client, vel=VELOCITY, acc=ACC)
        self._current_move(2, -100)

        time.sleep(1)
        self.get_logger().info("최종 투입 후 홈 복귀")
        self._movej(home, vel=VELOCITY, acc=ACC)


def main(args=None):
    # 1) rclpy 초기화
    rclpy.init(args=args)

    # 2) (중요) DSR 제어용 코어 노드를 먼저 생성 → DR_init 바인딩
    import DR_init as DRI
    dsr_core = rclpy.create_node("dsr_core", namespace=ROBOT_ID)
    DRI.__dsr__node  = dsr_core
    DRI.__dsr__id    = ROBOT_ID
    DRI.__dsr__model = ROBOT_MODEL

    # 3) 이제 DSR 계열을 **단 한 번** 임포트 (move.py와 동일 원리)
    #    이때 전역 초기화에서 create_client를 호출해도 dsr_core로 안전
    from DSR_ROBOT2 import movej, movel, check_force_condition, DR_AXIS_Z
    from DR_common2 import posx, posj

    # 4) 우리 패키지 유틸 임포트
    from .nav_waypoint import WaypointManager
    from .auto_move import drug_info, execute_from_key, current_move, current_move_two

    # 5) 애플리케이션 노드 생성(토픽 처리 전용) — DSR 함수는 주입
    app = GoBoxNode(
        movej, movel, check_force_condition, DR_AXIS_Z,
        posx, posj,
        WaypointManager,
        drug_info, execute_from_key, current_move, current_move_two
    )

    try:
        rclpy.spin(app)   # /go_main을 기다렸다가 실행
    finally:
        app.destroy_node()
        dsr_core.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
