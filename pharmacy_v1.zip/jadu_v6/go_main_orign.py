# go_main.py
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import json
import DR_init
import time
# from rclpy.lifecycle.node import Node

#------path------
from pathlib import Path

waypoint_file = (Path.home()/"ros2_ws"/"src"/"DoosanBootcamp3rd"/"dsr_rokey"/"rokey"/"rokey"/"basic"/"config"/"waypoint.json")
#------path------

GRIPPER_NAME="rg2"
TOOLCHARGER_IP = "192.168.1.1"
TOOLCHARGER_PORT = "502"

ROBOT_ID = "dsr01"
ROBOT_MODEL = "m0609"
VELOCITY, ACC = 60, 60

MD_NAME = ''

DR_init.__dsr__id = ROBOT_ID
DR_init.__dsr__model = ROBOT_MODEL
list_topic = ['/seg_start', '/box_start']

class GoBoxNode(Node):
    def __init__(self):
        super().__init__('go_box_node', namespace=ROBOT_ID)
        DR_init.__dsr__node = self

        self.seg_done_flag = False
        self.box_done_flag = False

        self.seg_pub = self.create_publisher(String, list_topic[0], 10)
        self.box_pub = self.create_publisher(String, list_topic[1], 10)
  

        self.seg_sub = self.create_subscription(String, '/seg_done', self.seg_done_cb, 10)
        self.box_sub = self.create_subscription(String, '/box_done', self.box_done_cb, 10)

        self.go_sub = self.create_subscription(String, '/go_main', self.md_name, 10)

        self.md_name_val = None


    
    ### pill_seg
    def seg_done_cb(self, msg):
        if msg.data.strip().lower() == "done":
            self.get_logger().info("pill_seg 완료 신호 수신")
            self.seg_done_flag = True

    def wait_for_seg_done(self):
        self.seg_done_flag = False
        while rclpy.ok() and not self.seg_done_flag:
            rclpy.spin_once(self, timeout_sec=0.1)


    ### box_seg
    def box_done_cb(self, msg): # 250815 작성한 box_done_cb, 원래 구현되어 있던 함수가 아니었음
        if msg.data.strip().lower() == "done":
            self.get_logger().info("box_seg 완료 신호 수신")
            self.box_done_flag = True

    def wait_for_box_done(self):
        self.box_done_flag = False
        while rclpy.ok() and not self.box_done_flag:
            rclpy.spin_once(self, timeout_sec=0.1)


    def run_pill(self, info):
        msg = String()
        msg.data = info
        self.seg_pub.publish(msg)
        self.get_logger().info(f"pill_seg 시작 신호 발행: {msg.data}")
        self.wait_for_seg_done()


    def run_box(self, info):
        msg = String()
        msg.data = info
        self.box_pub.publish(msg)
        self.get_logger().info(f"box_seg 시작 신호 발행: {msg.data}")
        self.wait_for_box_done()

    # 약 정보 받는 거
    def md_name(self, msg):
        # global MD_NAME
        self.md_name_val = msg.data
        # MD_NAME = msg.data
        self.get_logger().info(f"약 정보 수신 완료 {msg.data}")



def main(args=None):
    rclpy.init(args=args)
    node = GoBoxNode()
    DR_init.__dsr__node = node

    try:
        from DSR_ROBOT2 import (
            movej,movel, check_force_condition, DR_AXIS_Z
        )
        from DR_common2 import posx, posj
        from .nav_waypoint import WaypointManager
        from .auto_move import drug_info, execute_from_key, current_move, current_move_two
        # from .onrobot import RG
        from .basic_def import force_start, force_end

    except ImportError as e:
        print(f"Error importing DSR_ROBOT2 : {e}")
        return

    # gripper = RG(GRIPPER_NAME, TOOLCHARGER_IP, TOOLCHARGER_PORT)


    wp = WaypointManager(waypoint_file)



    home = wp.get_pos("home")
    client = wp.get_pos("client")

    # gripper.move_gripper(300)
    
    movej(home, vel=VELOCITY, acc=ACC)

    # name = input("어디로 갈까요? ").strip()
    # name = MD_NAME
    name = node.md_name_val
    # print(MD_NAME, "===MD_NAME===\n")

    pos1 = posx([496.06, 93.46, 296.92, 20.75, 179.00, 19.09])
    pos2 = posx([548.70, -193.46, 96.92, 20.75, 179.00, 19.09])
    movel(pos1, vel=VELOCITY, acc=ACC)
    movel(pos2, vel=VELOCITY, acc=ACC)


    info = drug_info(name)
    if not info:
        print("[ERROR] 해당 이름 없음")
        return

    if info['group'] == 'list_drug':
        execute_from_key(info['pos'], step="pick")

        current_move(2, 25)
        # node.run_pill(name) ### 알약 집고 조금 드는 것까지 동작함 ####################################################################

        current_move(2, 100) ### 여기서부터 알약을 상자로 옮겨서 놓는 것을 하던지 / 열린 서랍을 먼저 닫고 하던지 정해서 진행하면 됨
        current_move(0, -100)
        execute_from_key(info['pos'], step="place")

        # , vel=VELOCITY, acc=ACC
        movej(home, vel=VELOCITY, acc=ACC)
        # 캡슐을 잡아서 위로 올리는 것 까지만 진행 하면 됨



        # movel(posx([346.165, 234.503, 45.317, 24.895, -179.953, -70.178]), vel=VELOCITY, acc=ACC)
        # gripper.move_gripper(300)
        # current_move(2, 20)
        # current_move(1, 60)
        # current_move(2, -30)
        # movel(posx([346.297, 245.098, 39.873, 30.492, 179.998, -64.633]), vel=VELOCITY, acc=ACC)

        # # 힘제어로 캡슐 닫기
        # force_start(100, -15)
        # while not check_force_condition(DR_AXIS_Z, max=7):
        #         pass
        # force_end()

        # # 그리퍼가 잡기 쉽게 자세 잡기
        # movel(posx([346.123, 254.796, 45.364, 23.685, -179.958, -71.415]), vel=VELOCITY, acc=ACC)
        # movej(posj([35.367, 12.69, 99.83, -0.059, 67.513, -149.557]), vel=VELOCITY, acc=ACC)
        
        # # 캡슐 잡아서 올리기
        # gripper.move_gripper(450)
        # current_move(2, -30)
        # current_move(1, -20)
        # gripper.move_gripper(400)
        # current_move(2, 50)



    elif info['group'] == 'list_box':
        # node.run_box(name) # ###################################################################
        # 진행 안해도 됨
        # pass # ###################################################################

        pos1 = posx([496.06, 93.46, 296.92, 20.75, 179.00, 19.09])
        pos2 = posx([548.70, -193.46, 96.92, 20.75, 179.00, 19.09])
        movel(pos1, vel=VELOCITY, acc=ACC)
        movel(pos2, vel=VELOCITY, acc=ACC)


    
    # 손님에게 줄 처방 봉투 위로 이동 및 내려가서 놓기
    movel(client, vel=VELOCITY, acc=ACC)
    current_move(2, -100)


    # gripper.move_gripper(500)


    time.sleep(1)
    # 최종 봉투로 투척
    movej(home, vel=VELOCITY, acc=ACC)

    # gripper.move_gripper(500)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

'''
개선점

------------------------------
1. 쓸 데 없는 움직임이 좀 있음
해결법 : 다양한 move를 잘 사용하면 시간 단축 가능할듯
'''