# go_main.py (patched)
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import json
import DR_init
import time
from pathlib import Path

#------path------
waypoint_file = (Path.home()/"ros2_ws"/"src"/"DoosanBootcamp3rd"/"dsr_rokey"/"rokey"/"rokey"/"basic"/"config"/"waypoint.json")
#------path------

GRIPPER_NAME="rg2"
TOOLCHARGER_IP = "192.168.1.1"
TOOLCHARGER_PORT = "502"

ROBOT_ID = "dsr01"
ROBOT_MODEL = "m0609"
VELOCITY, ACC = 30, 30

DR_init.__dsr__id = ROBOT_ID
DR_init.__dsr__model = ROBOT_MODEL

list_topic = ['/seg_start', '/box_start']

class GoBoxNode(Node):
    def __init__(self):
        super().__init__('go_box_node', namespace=ROBOT_ID)
        DR_init.__dsr__node = self
     

        # 상태 플래그
        self.seg_done_flag = False
        self.box_done_flag = False
        self.running = False                 # 동작 중 중복 실행 방지
        self.MD_NAME = ""                    # 전역 대신 인스턴스 변수로 보관

        # pub/sub
        self.seg_pub = self.create_publisher(String, list_topic[0], 10)
        self.box_pub = self.create_publisher(String, list_topic[1], 10)

        self.seg_sub = self.create_subscription(String, '/seg_done', self.seg_done_cb, 10)
        self.box_sub = self.create_subscription(String, '/box_done', self.box_done_cb, 10)

        # ★ 핵심: /go_main 수신 시 동작 트리거
        self.go_sub  = self.create_subscription(String, '/go_main', self.md_name_cb, 10)

    # --- pill_seg ---
    def seg_done_cb(self, msg: String):
        if msg.data.strip().lower() == "done":
            self.get_logger().info("pill_seg 완료 신호 수신")
            self.seg_done_flag = True

    def wait_for_seg_done(self):
        self.seg_done_flag = False
        while rclpy.ok() and not self.seg_done_flag:
            rclpy.spin_once(self, timeout_sec=0.1)

    # --- box_seg ---
    def box_done_cb(self, msg: String):
        if msg.data.strip().lower() == "done":
            self.get_logger().info("box_seg 완료 신호 수신")
            self.box_done_flag = True

    def wait_for_box_done(self):
        self.box_done_flag = False
        while rclpy.ok() and not self.box_done_flag:
            rclpy.spin_once(self, timeout_sec=0.1)

    def run_pill(self, info: str):
        msg = String()
        msg.data = info
        self.seg_pub.publish(msg)
        self.get_logger().info(f"pill_seg 시작 신호 발행: {msg.data}")
        self.wait_for_seg_done()

    def run_box(self, info: str):
        msg = String()
        msg.data = info
        self.box_pub.publish(msg)
        self.get_logger().info(f"box_seg 시작 신호 발행: {msg.data}")
        self.wait_for_box_done()

    # ★ /go_main 콜백: 약 이름 수신 → 시퀀스 실행
    def md_name_cb(self, msg: String):
        name = msg.data.strip()
        self.get_logger().info(f"/go_main 수신: '{name}'")
        if not name:
            self.get_logger().warn("빈 약 이름 수신. 동작 생략.")
            return
        if self.running:
            self.get_logger().warn("이미 동작 중입니다. 새로운 요청은 무시합니다.")
            return

        self.MD_NAME = name
        self.running = True
        try:
            self.execute_flow(self.MD_NAME)
        except Exception as e:
            self.get_logger().error(f"동작 실행 중 예외: {e}")
        finally:
            self.running = False

    # ★ 실제 로봇 시퀀스(기존 main 내부 로직 이동)
    def execute_flow(self, name: str):
        # 지연 임포트: 장치/라이브러리 의존 모듈은 실행 시점에 로드
        from DSR_ROBOT2 import movej, movel, check_force_condition, DR_AXIS_Z
        from DR_common2 import posx, posj
        from .nav_waypoint import WaypointManager
        from .auto_move import drug_info, execute_from_key, current_move, current_move_two
        # from .onrobot import RG
        from .basic_def import force_start, force_end

        

        wp = WaypointManager(waypoint_file)
        home = wp.get_pos("home")
        client = wp.get_pos("client")

        # gripper = RG(GRIPPER_NAME, TOOLCHARGER_IP, TOOLCHARGER_PORT)
        # gripper.move_gripper(300)

        self.get_logger().info("홈 포즈로 이동")
        movej(home, vel=VELOCITY, acc=ACC)

        self.get_logger().info(f"수신 약 이름으로 정보 조회: {name}")
        info = drug_info(name)
        if not info:
            self.get_logger().error("[ERROR] 해당 약 이름이 waypoint에 없습니다.")
            return

        if info['group'] == 'list_drug':
            execute_from_key(info['pos'], step="pick")

            # 캡슐 집고 살짝 들어올리기
            current_move(2, 25)

            # ↓ 이후 프로세스 (예: 상자로 옮겨 놓기)
            current_move(2, 100)
            current_move(0, -100)
            execute_from_key(info['pos'], step="place")

            movej(home, vel=VELOCITY, acc=ACC)

        elif info['group'] == 'list_box':
            # 박스 작업이 필요하면 여기에
            self.get_logger().info("박스 동작은 현재 가상 테스트 중입니다.")
            # self.run_box(name)

            pos1 = posx([496.06, 93.46, 296.92, 20.75, 179.00, 19.09])
            pos2 = posx([548.70, -193.46, 96.92, 20.75, 179.00, 19.09])
            movel(pos1, vel=VELOCITY, acc=ACC)
            movel(pos2, vel=VELOCITY, acc=ACC)

        # 고객 봉투 상부로 이동 후 내려놓기
        movel(client, vel=VELOCITY, acc=ACC)
        # gripper.move_gripper(500)  # 필요 시
        current_move(2, -100)

        time.sleep(1)
        self.get_logger().info("최종 투입 후 홈 복귀")
        movej(home, vel=VELOCITY, acc=ACC)

def main(args=None):
    rclpy.init(args=args)
    node = GoBoxNode()
    try:
        # ★ 핵심: 스핀으로 대기 → /go_main 수신 시에만 실행
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
