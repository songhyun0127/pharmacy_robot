import os
os.environ["CUDA_VISIBLE_DEVICES"] = ""  # GPU 비활성화 (필요 시 제거)

import cv2
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from .realsense import ImgNode
from scipy.spatial.transform import Rotation
from .onrobot import RG
from ultralytics import YOLO
import time
import numpy as np
import DR_init
from rclpy.executors import MultiThreadedExecutor
#------path------
from pathlib import Path
config_dir = Path(__file__).parent / "config"

TGRIPPER_FILE = config_dir / "T_gripper2camera.npy"
YOLO_PILL_MODEL_FILE = config_dir / "my_best_pill_2.pt"

# tgripper_file = (Path.home()/"ros2_ws"/"src"/"DoosanBootcamp3rd"/"dsr_rokey"/"rokey"/"rokey"/"basic"/"config"/"T_gripper2camera.npy")
# yolo_pill_model_file = (Path.home()/"ros2_ws"/"src"/"DoosanBootcamp3rd"/"dsr_rokey"/"rokey"/"rokey"/"basic"/"config"/"my_best_pill_2.pt")
#------path------

# 로봇 및 그리퍼 설정
ROBOT_ID = "dsr01"
ROBOT_MODEL = "m0609"
VELOCITY, ACC = 60, 60

DR_init.__dsr__id = ROBOT_ID
DR_init.__dsr__model = ROBOT_MODEL

GRIPPER_NAME = "rg2"
TOOLCHARGER_IP = "192.168.1.1"
TOOLCHARGER_PORT = "502"
from pharmacy_interface.srv import MediInfo

# YOLO & SEGMENTATION SETTINGS
CONFIDENCE_THRESHOLD = 0.7
ROI = (100, 100, 540, 380)  # (x_start, y_start, x_end, y_end) - 관심 영역


class PillSegmenterNode(Node):
    """
    YOLOv8을 사용하여 알약을 감지하고 로봇 팔을 제어하여 집는 ROS2 노드.
    '/seg_start' 서비스 요청을 받으면 작업을 수행.
    """
    def __init__(self, robot_api):
        super().__init__("pill_segmenter_node", namespace=ROBOT_ID)
        self.robot_api = robot_api
        self.get_logger().info("PillSegmenterNode 초기화 시작...")
        self.medi_name = ''
        # Load YOLO model
        try:
            self.model = YOLO(YOLO_PILL_MODEL_FILE)
            self.get_logger().info(f"YOLO 모델 로드 완료: {YOLO_PILL_MODEL_FILE}")
        except Exception as e:
            self.get_logger().error(f"YOLO 모델 로드 실패: {e}")
            rclpy.shutdown()
            return

        # Initialize Camera
        self.img_node = ImgNode()
        self.intrinsics = self._wait_for_intrinsics()
        if not self.intrinsics:
            self.get_logger().error("카메라 Intrinsic 정보를 얻지 못해 노드를 종료합니다.")
            rclpy.shutdown()
            return

        # Load Transformation Matrix
        try:
            self.gripper2cam = np.load(TGRIPPER_FILE)
        except FileNotFoundError:
            self.get_logger().error(f"변환 행렬 파일을 찾을 수 없습니다: {TGRIPPER_FILE}")
            rclpy.shutdown()
            return

        # Initialize Gripper
        self.gripper = RG(GRIPPER_NAME, TOOLCHARGER_IP, TOOLCHARGER_PORT)

        # ROS2 Service Server
        self.srv = self.create_service(MediInfo, '/seg_start', self.segmentation_service_callback)

        self.get_logger().info("초기화 완료. '/seg_start' 서비스 요청을 기다립니다.")

    def _wait_for_intrinsics(self):
        """카메라 내부 파라미터를 얻을 때까지 대기합니다."""
        for _ in range(50):  # 5초 동안 시도
            rclpy.spin_once(self.img_node, timeout_sec=0.1)
            intrinsics = self.img_node.get_camera_intrinsic()
            if intrinsics:
                self.get_logger().info("카메라 Intrinsic 정보 획득.")
                return intrinsics
            self.get_logger().warn("카메라 Intrinsic 대기 중...")
        return None

    def segmentation_service_callback(self, request, response):
        """'/seg_start' 서비스 요청 시 호출되는 콜백 함수."""
        self.get_logger().info(f"서비스 요청 수신: '{request.medi_name}' (is_run: {request.is_run})")

        if not request.is_run:
            self.get_logger().warn("is_run 플래그가 False이므로 작업을 실행하지 않습니다.")
            response.get_info = False
            return response

        # 작업 수행 및 성공 여부 반환
        success = self.execute_segmentation_task(request.medi_name)
        self.medi_name = request.medi_name
        response.get_info = success
        self.get_logger().info(f"작업 완료. 성공 여부: {success}")
        return response

    def execute_segmentation_task(self, target_name):
        """알약 탐지 및 피킹 작업을 수행하고 성공 여부를 반환합니다."""
        self.get_logger().info("유효한 프레임 획득 시도 중...")
        color_frame, depth_frame = None, None
        for _ in range(10): # 5초간 시도
            color_frame, depth_frame = self.get_frames()
            if color_frame is not None and depth_frame is not None:
                self.get_logger().info("프레임 획득 성공.")
                break
            self.get_logger().warn("유효한 프레임을 얻지 못했습니다. 0.5초 후 재시도합니다.")
            time.sleep(0.5)

        if color_frame is None or depth_frame is None:
            self.get_logger().error("최종적으로 유효한 프레임을 얻지 못했습니다.")
            return False

        target_info = self.find_target_in_roi(color_frame, target_name.strip().lower())

        if not target_info:
            self.get_logger().info(f"관심 영역에서 '{target_name}'을(를) 찾지 못했습니다.")
            return False

        z = self.get_depth_value(target_info["center_x"], target_info["center_y"], depth_frame)
        if not z:
            self.get_logger().warn("유효한 깊이 값을 얻지 못했습니다.")
            return False

        robot_coord = self.transform_coordinates(target_info, z)
        if robot_coord is None:
            self.get_logger().error("좌표 변환에 실패했습니다.")
            return False

        return self.perform_pick(robot_coord, target_info["angle"])

    def get_frames(self):
        """카메라로부터 컬러 및 깊이 프레임을 획득합니다."""
        rclpy.spin_once(self.img_node, timeout_sec=0.1)
        return self.img_node.get_color_frame(), self.img_node.get_depth_frame()

    def find_target_in_roi(self, frame, target_name):
        """관심 영역(ROI) 내에서 타겟 객체를 찾습니다."""
        x1, y1, x2, y2 = ROI
        roi_frame = frame[y1:y2, x1:x2]

        results = self.model(roi_frame, verbose=False)
        
        if not results or results[0].masks is None:
            return None

        names_map = results[0].names
        target_contours = []

        for i, conf in enumerate(results[0].boxes.conf):
            if conf < CONFIDENCE_THRESHOLD:
                continue
            
            cls_id = int(results[0].boxes.cls[i])
            detected_name = names_map[cls_id].lower()

            if detected_name == target_name:
                contour = results[0].masks.xy[i]
                # ROI 좌표계를 전체 프레임 좌표계로 변환
                contour[:, 0] += x1
                contour[:, 1] += y1
                target_contours.append(contour)

        if not target_contours:
            return None

        largest_contour = max(target_contours, key=cv2.contourArea)
        (cx, cy), (w, h), angle = cv2.minAreaRect(largest_contour)
        
        final_angle = angle if h < w else angle - 90

        return {"center_x": cx, "center_y": cy, "angle": final_angle}

    def get_depth_value(self, cx, cy, depth_frame):
        """주어진 좌표의 깊이 값을 반환합니다."""
        h, w = depth_frame.shape
        if 0 <= cx < w and 0 <= cy < h:
            depth = depth_frame[int(cy), int(cx)]
            return depth if depth > 0 else None
        return None

    def transform_coordinates(self, target_info, z):
        """카메라 좌표를 로봇 베이스 좌표로 변환합니다."""
        cam_coords = self._get_camera_pos(target_info["center_x"], target_info["center_y"], z)
        
        current_posx = self._get_reliable_current_posx()
        if not current_posx:
            self.get_logger().error("현재 로봇 포즈를 얻을 수 없습니다.")
            return None

        base2gripper = self._get_pose_matrix(*current_posx)
        base2cam = base2gripper @ self.gripper2cam
        
        cam_coord_homogeneous = np.append(np.array(cam_coords), 1)
        base_coord = base2cam @ cam_coord_homogeneous
        
        return base_coord[:3]

    def _get_camera_pos(self, cx, cy, z):
        """2D 이미지 좌표와 깊이 값을 3D 카메라 좌표로 변환합니다."""
        fx, fy = self.intrinsics["fx"], self.intrinsics["fy"]
        ppx, ppy = self.intrinsics["ppx"], self.intrinsics["ppy"]
        cam_x = (cx - ppx) * z / fx
        cam_y = (cy - ppy) * z / fy
        return cam_x, cam_y, z

    def _get_reliable_current_posx(self, retries=20, delay=0.1):
        """안정적으로 로봇의 현재 TCP 포즈를 가져옵니다."""
        for attempt in range(retries):
            try:
                posx_info = self.robot_api['get_current_posx']()
                if posx_info and isinstance(posx_info[0], (list, tuple)) and len(posx_info[0]) >= 6:
                    return posx_info[0]
                self.get_logger().warn(f"[{attempt+1}/{retries}] 포즈 정보가 유효하지 않습니다: {posx_info}. 재시도합니다.")
            except IndexError:
                self.get_logger().warn(f"[{attempt+1}/{retries}] get_current_posx() 호출 중 내부 오류(IndexError) 발생. 재시도합니다.")
            
            time.sleep(delay)
        
        self.get_logger().error("최종적으로 포즈 정보를 가져오는 데 실패했습니다.")
        return None

    def _get_pose_matrix(self, x, y, z, rx, ry, rz):
        """오일러 각으로부터 변환 행렬을 생성합니다."""
        R = Rotation.from_euler("ZYZ", [rx, ry, rz], degrees=True).as_matrix()
        T = np.eye(4)
        T[:3, :3] = R
        T[:3, 3] = [x, y, z]
        return T

    def perform_pick(self, coords, angle):
        """지정된 좌표와 각도로 피킹 동작을 수행하고 성공 여부를 반환합니다."""
        x, y, z = coords
        self.get_logger().info(f"피킹 시작: 위치=({x:.2f}, {y:.2f}, {z:.2f}), 각도={angle:.2f}")

        current_pos = self._get_reliable_current_posx()
        if not current_pos:
            self.get_logger().error("피킹 동작 중 현재 위치를 얻지 못해 중단합니다.")
            return False

        target_orientation = [current_pos[3], current_pos[4], angle]

        # 1. 접근 위치로 이동
        approach_pos = self.robot_api['posx']([x, y, current_pos[2], *target_orientation])
        self.robot_api['movel'](approach_pos, VELOCITY, ACC)
        self.robot_api['wait'](1)

        # 2. 그리퍼 열기
        self.gripper.move_gripper(300)
        self.robot_api['wait'](1)

        # 3. 피킹 위치로 이동
        if self.medi_name == 'zaide':
            pick_pos = self.robot_api['posx']([x, y, z + 15, *target_orientation])
        else:
            pick_pos = self.robot_api['posx']([x, y, z + 12, *target_orientation])
        self.robot_api['movel'](pick_pos, VELOCITY / 2, ACC / 2)
        self.robot_api['wait'](1)

        # 4. 잡기
        self.gripper.move_gripper(150)
        self.robot_api['wait'](1)
        
        # 5. 들어올리기
        lift_pos = self.robot_api['posx']([x, y, current_pos[2], *target_orientation])
        self.robot_api['movel'](lift_pos, VELOCITY, ACC)
        self.robot_api['wait'](1)

        self.get_logger().info("피킹 동작 완료.")
        return True


def main(args=None):
    rclpy.init(args=args)
    node = rclpy.create_node("pill_seg_node", namespace=ROBOT_ID)
    DR_init.__dsr__node = node

    from DSR_ROBOT2 import get_current_posx, movej, movel, wait
    from DR_common2 import posx, posj
    robot_api = {
        "posx": posx,
        "posj": posj,
        "movej": movej,
        "movel": movel,
        "get_current_posx": get_current_posx,
        "wait": wait
    }
    seg_node = PillSegmenterNode(robot_api)

    try:
        executor = MultiThreadedExecutor(num_threads=2)   # 2~3 권장
        executor.add_node(seg_node)                       # 세그 노드
        executor.add_node(seg_node.img_node)              # <<< 카메라 노드 함께 등록
        executor.add_node(node)                           # DSR dummy
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        seg_node.destroy_node()
        seg_node.img_node.destroy_node()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()
