#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import String


import DR_init

ROBOT_ID = "dsr01"
DR_init.__dsr__id = ROBOT_ID


class MedicinePublisher(Node):
    def __init__(self):
        super().__init__('medicine_publisher',  namespace=ROBOT_ID)
        # 퍼블리셔 생성 (토픽 이름: /medicine_topic, 메시지 타입: String)
        self.publisher_ = self.create_publisher(String, '/go_main', 10)

        # ✅ 터미널에서 입력값 받기
        self.medicine_list = ['penzal', 'sky', 'tg', 'zaide', 'famotidine', 'somnifacient', 'allergy']
        self.get_logger().info(f"사용 가능한 값: {self.medicine_list}")

        user_input = input("어떤 약을 선택하시겠습니까? >> ")

        if user_input in self.medicine_list:
            msg = String()
            msg.data = user_input
            self.publisher_.publish(msg)
            self.get_logger().info(f"토픽 발행 완료: {msg.data}")
        else:
            self.get_logger().warn(f"'{user_input}' 는 리스트에 없는 값입니다!")

def main(args=None):
    rclpy.init(args=args)
    node = MedicinePublisher()
    # 발행 후 바로 종료
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
