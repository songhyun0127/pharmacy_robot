# ROS2 통신 방식 개선: 토픽에서 서비스로의 전환

## 1. 개요

본 문서는 `go_main.py`, `pill_seg.py`, `box_seg.py` 세 개의 ROS2 노드 간의 통신 방식을 기존의 토픽(Topic) 기반에서 서비스(Service) 기반으로 전환하는 과정과 그 결과를 상세히 기록합니다. 이 작업의 주된 목표는 통신의 신뢰성을 높이고, 각 노드의 역할을 명확히 하며, 전체 시스템의 아키텍처를 개선하는 것입니다.

---

## 2. 초기 요구사항 및 문제 분석

### 2.1. 기존 아키텍처

*   **`go_main.py`**: 중앙 관제 노드. `/go_main` 토픽으로 약품 이름을 받으면, `/seg_start` 또는 `/box_start` 토픽을 발행하여 각 작업 노드에 명령을 전달. `threading.Event`를 사용하여 `/seg_done`, `/box_done` 토픽이 발행되기를 기다림으로써 작업 완료를 확인.
*   **`pill_seg.py` / `box_seg.py`**: 작업 수행 노드. 각각 `/seg_start`, `/box_start` 토픽을 구독하여 작업을 시작하고, 완료되면 `/seg_done`, `/box_done` 토픽을 발행.

### 2.2. 문제점

*   **신뢰성 부족**: 토픽은 발행-구독(Pub-Sub) 모델 특성상 메시지 전달이 100% 보장되지 않습니다. 네트워크 상황에 따라 시작 또는 완료 신호가 유실될 가능성이 존재했습니다.
*   **복잡한 상태 관리**: `go_main` 노드는 작업 완료를 확인하기 위해 `threading.Event`와 같은 복잡한 동기화 메커니즘을 사용해야 했습니다. 이로 인해 코드가 복잡해지고 잠재적인 경쟁 상태(Race Condition)의 위험이 있었습니다.
*   **불명확한 역할**: 모든 노드가 발행자와 구독자의 역할을 동시에 수행하여, 요청(Request)과 응답(Response)의 관계가 명확하지 않았습니다.

---

## 3. 해결 과정 및 최종 아키텍처

### 3.1. 초기 제안

처음에는 ROS2의 기본 서비스인 `std_srvs/srv/Trigger`를 사용하여 통신 구조를 변경하는 것을 제안했습니다. 하지만 이 서비스는 단순히 신호만 전달할 뿐, 작업에 필수적인 데이터(예: 약품 이름)를 함께 전송할 수 없는 한계가 명확했습니다.

### 3.2. 사용자 정의 서비스 인터페이스 도입

이러한 한계를 해결하기 위해, 사용자는 직접 `pharmacy_interface` 패키지를 생성하고 다음과 같은 내용의 사용자 정의 서비스 `MediInfo.srv`를 정의했습니다. 이는 이번 아키텍처 개선의 핵심적인 전환점이 되었습니다.

**파일 경로:** `/home/ohjunseok/ros2_ws/src/pharmacy_interface/srv/MediInfo.srv`

**서비스 정의:**
```srv
# Request
string medi_name
bool is_run
---
# Response
bool get_info
```
이 서비스를 통해 약품 이름(`medi_name`)과 실행 여부(`is_run`)를 요청에 담아 보낼 수 있게 되었고, 작업 성공 여부(`get_info`)를 응답으로 받을 수 있게 되어 매우 이상적인 통신 모델을 구축할 수 있었습니다.

### 3.3. 최종 아키텍처

새로운 `MediInfo` 서비스를 기반으로 전체 시스템을 서비스 클라이언트-서버 모델로 재설계했습니다.

*   **`go_main.py` (서비스 클라이언트):**
    *   `/seg_start`와 `/box_start` 서비스의 클라이언트로 동작합니다.
    *   작업이 필요할 때, `MediInfo.Request`에 약품 이름과 `is_run=True`를 담아 서비스를 호출합니다.
    *   `rclpy.spin_until_future_complete`를 사용하여 서비스의 응답이 올 때까지 명확하고 동기적으로 대기합니다. 이로써 기존의 복잡한 `threading.Event` 로직이 완전히 제거되었습니다.

*   **`pill_seg.py` & `box_seg.py` (서비스 서버):**
    *   각각 `/seg_start`, `/box_start` 서비스의 서버로 동작합니다.
    *   평소에는 유휴 상태(idle)로 대기하다가, 서비스 요청이 들어왔을 때만 활성화됩니다.
    *   요청에 담긴 `medi_name`을 확인하여 작업을 수행하고, 모든 과정이 성공적으로 완료되면 `response.get_info = True`를 설정하여 클라이언트에게 응답을 보냅니다.

---

## 4. 코드 변경 내역

*   **`/home/ohjunseok/ros2_ws/src/DoosanBootcamp3rd/dsr_rokey/rokey/rokey/jadu_v6/go_main.py`**:
    *   `pharmacy_interface.srv.MediInfo` 임포트.
    *   기존 토픽 publisher/subscriber 및 `threading.Event` 관련 코드 제거.
    *   `MediInfo` 타입의 서비스 클라이언트 2개(`pill_seg_client`, `box_seg_client`) 생성.
    *   `run_pill`, `run_box` 함수를 서비스 호출 및 응답 대기 로직으로 재작성.

*   **`/home/ohjunseok/ros2_ws/src/DoosanBootcamp3rd/dsr_rokey/rokey/rokey/jadu_v6/pill_seg.py`**:
    *   `pharmacy_interface.srv.MediInfo` 임포트.
    *   기존 토픽 subscriber/publisher 제거.
    *   `MediInfo` 타입의 서비스 서버(`seg_service`) 생성.
    *   서비스 콜백 함수(`seg_service_callback`) 내에서 모든 작업(탐지, 이동, 피킹)을 수행하고 결과를 응답으로 반환하도록 로직 통합.

*   **`/home/ohjunseok/ros2_ws/src/DoosanBootcamp3rd/dsr_rokey/rokey/rokey/jadu_v6/box_seg.py`**:
    *   `pharmacy_interface.srv.MediInfo` 임포트.
    *   기존 토픽 subscriber/publisher 제거.
    *   `MediInfo` 타입의 서비스 서버(`box_service`) 생성.
    *   서비스 콜백 함수(`box_service_callback`) 내에서 작업 흐름을 제어하고, 별도 스레드에서 수행되는 로봇 이동의 완료를 `threading.Event`로 내부적으로 기다린 후 최종 응답을 반환하도록 수정.

## 5. 결론 및 기대효과

이번 리팩토링을 통해 다음과 같은 뚜렷한 개선 효과를 얻었습니다.

1.  **신뢰성 향상**: 요청-응답이 보장되는 서비스 통신을 통해 작업의 시작과 끝을 100% 보장할 수 있게 되었습니다.
2.  **코드 가독성 및 유지보수성 증진**: 복잡한 비동기 처리 로직이 직관적인 서비스 호출로 변경되어 코드의 이해가 쉬워졌습니다.
3.  **시스템 아키텍처 개선**: 클라이언트와 서버의 역할이 명확히 분리되어, 각 노드의 책임과 역할이 뚜렷해졌으며 이는 향후 기능 확장에 유연하게 대처할 수 있는 기반이 됩니다.
