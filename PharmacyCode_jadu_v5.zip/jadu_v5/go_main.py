# go_box_edit_by_jsg.py
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from std_msgs.msg import Float64MultiArray
import json
import DR_init
import time

#------path------
from pathlib import Path

waypoint_file = (Path.home()/"ros2_ws"/"src"/"DoosanBootcamp3rd"/"dsr_rokey"/"rokey"/"rokey"/"basic"/"config"/"waypoint.json")
#------path------

GRIPPER_NAME="rg2"
TOOLCHARGER_IP = "192.168.1.1"
TOOLCHARGER_PORT = "502"

ROBOT_ID = "dsr01"
ROBOT_MODEL = "m0609"
VELOCITY, ACC = 30, 30

DR_init.__dsr__id = ROBOT_ID
DR_init.__dsr__model = ROBOT_MODEL
list_topic = ['/seg_start', '/box_start']


DATA = []




class GoBoxNode(Node):
    def __init__(self):
        super().__init__('go_box_node', namespace=ROBOT_ID)
        DR_init.__dsr__node = self

        self.seg_done_flag = False
        self.box_done_flag = False



        self.seg_pub = self.create_publisher(String, list_topic[0], 10)
        self.box_pub = self.create_publisher(String, list_topic[1], 10)

        self.seg_sub = self.create_subscription(String, '/seg_done', self.seg_done_cb, 10)
        self.box_sub = self.create_subscription(String, '/box_done', self.box_done_cb, 10)

        # 토픽 구독 설정
        self.create_subscription(
            Float64MultiArray, "/dsr01/msg/current_posx", self.current_posx_callback, 10
        )
        

    
    ### seg_test1
    def seg_done_cb(self, msg):
        if msg.data.strip().lower() == "done":
            self.get_logger().info("seg_test1 완료 신호 수신")
            self.seg_done_flag = True

    def wait_for_seg_done(self):
        self.seg_done_flag = False
        while rclpy.ok() and not self.seg_done_flag:
            rclpy.spin_once(self, timeout_sec=0.1)


    ### yolo_move_cp1
    def box_done_cb(self, msg): # 250815 작성한 box_done_cb, 원래 구현되어 있던 함수가 아니었음
        if msg.data.strip().lower() == "done":
            self.get_logger().info("yolo_move_cp1 완료 신호 수신")
            self.box_done_flag = True

    def wait_for_box_done(self):
        self.box_done_flag = False
        while rclpy.ok() and not self.box_done_flag:
            rclpy.spin_once(self, timeout_sec=0.1)


    def run_seg(self, info):
        msg = String()
        msg.data = info
        self.seg_pub.publish(msg)
        self.get_logger().info(f"seg_test1 시작 신호 발행: {msg.data}")
        self.wait_for_seg_done()


    def run_box(self, info):
        msg = String()
        msg.data = info
        self.box_pub.publish(msg)
        self.get_logger().info(f"box_test1 시작 신호 발행: {msg.data}")
        self.wait_for_box_done()


    def current_posx_callback(self, msg):
        self.current_posx_msg = msg
        DATA = [round(d, 3) for d in self.current_posx_msg.data]
        # 텍스트 박스 업데이트 (첫 번째 텍스트 박스)
        # self.get_logger().info(f"posx({data})")
        # self.current_pos = data
        return DATA
    
    def logo(self, something):
        self.get_logger().info(f"무언의 값 : {something}")
   


def main(args=None):
    rclpy.init(args=args)
    node = GoBoxNode()
    DR_init.__dsr__node = node

    try:
        from DSR_ROBOT2 import (
            movej,movel, check_force_condition, DR_AXIS_Z, get_current_posx
        )
        from DR_common2 import posx, posj
        from .nav_waypoint import WaypointManager
        from .auto_move import drug_info, execute_from_key, current_move
        from .onrobot import RG
        from .basic_def import force_start, force_end

    except ImportError as e:
        print(f"Error importing DSR_ROBOT2 : {e}")
        return

    gripper = RG(GRIPPER_NAME, TOOLCHARGER_IP, TOOLCHARGER_PORT)


    wp = WaypointManager(waypoint_file)



    home = wp.get_pos("home")
    gripper.move_gripper(300)
    movej(home, vel=VELOCITY, acc=ACC)

    print("------ 알약 -----\n",
        "zaide   4-1\n",
        "penzal   4-2\n",
        "tg   4-3\n",
        "sky   4-4\n",
        "----- 박스 약 -----\n",
        "famotidine   박스 중앙\n",
        "somnifacient   박스 오른쪽\n",
        "allergy   박스 왼쪽\n")
    
    name = input("어디로 갈까요? ").strip()
    info = drug_info(name)
    if not info:
        print("[ERROR] 해당 이름 없음")
        return

    if info['group'] == 'list_drug':
        ### 알약 시나리오

        execute_from_key(info['pos'], step="pick")

        current_move(2, 25)

        # 여기서 혹은 pill_seg 내에서 z축 아래로 일치를 하는 코드가 필요함!!!

        if name == 'penzal':
            movel(posx([399.3, -172.38, 110, 151.67, 180, -113.27]), vel=VELOCITY, acc=ACC)
        if name == 'zaide':
            movel(posx([402.6, -54.02, 110, 175.42, -180, -95.63]), vel=VELOCITY, acc=ACC)

        # z축 아래 일치 한 다음 아래 코드를 실행해야 알약 박스 아래칸 동작이 문제 없이 진행됨


        ### 알약 집는 pill_seg 동작 시작
        node.run_seg(name) ### 알약 집고 조금 드는 것까지 동작함
        current_move(2, 100) ### 여기서부터 알약을 상자로 옮겨서 놓는 것을 하던지 / 열린 서랍을 먼저 닫고 하던지 정해서 진행하면 됨
        ### 0815 기록으로는 상자부터 닫고 캡슐로 알약 넣기 실행 중

        current_move(0, -100)
        execute_from_key(info['pos'], step="place")
        
        
        
        
        # , vel=VELOCITY, acc=ACC
        movej(home, vel=VELOCITY, acc=ACC)
        # 캡슐 바로 위로 이동
        movel(posx([346.165, 234.503, 45.317, 24.895, -179.953, -70.178]), vel=VELOCITY, acc=ACC)
        gripper.move_gripper(300) # 그리퍼 벌려서 알약 캡슐에 넣기
        
        # 캡슐 닫는 행동 시작
        current_move(2, 20)
        current_move(1, 60)
        current_move(2, -30)
        movel(posx([346.297, 245.098, 39.873, 30.492, 179.998, -64.633]), vel=VELOCITY, acc=ACC)

        # 힘제어로 캡슐 닫기
        force_start(100, -15)
        while not check_force_condition(DR_AXIS_Z, max=7):
                pass
        force_end()

        # 그리퍼가 잡기 쉽게 자세 잡기
        movel(posx([346.123, 254.796, 45.364, 23.685, -179.958, -71.415]), vel=VELOCITY, acc=ACC)
        movej(posj([35.367, 12.69, 99.83, -0.059, 67.513, -149.557]), vel=VELOCITY, acc=ACC)
        
        # 캡슐 잡아서 올리기
        gripper.move_gripper(450)
        current_move(2, -30)
        current_move(1, -20)
        gripper.move_gripper(400)
        current_move(2, 50)



    elif info['group'] == 'list_box':
        ### 박스 시나리오

        node.run_box(name)
        # 진행 안해도 됨

    # 최종 봉투로 투척
    # movej(home, vel=VELOCITY, acc=ACC)


    gripper.move_gripper(500)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
