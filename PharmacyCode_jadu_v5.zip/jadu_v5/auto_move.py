from DR_common2 import posx
from .onrobot import RG
import time
from DSR_ROBOT2 import movel, get_current_posx
from .nav_waypoint import WaypointManager
import json

#------path------
from pathlib import Path

waypoint_file = (Path.home()/"ros2_ws"/"src"/"DoosanBootcamp3rd"/"dsr_rokey"/"rokey"/"rokey"/"basic"/"config"/"waypoint.json")
wp = WaypointManager(waypoint_file)
#------path------

GRIPPER_NAME = "rg2"
TOOLCHARGER_IP = "192.168.1.1"
TOOLCHARGER_PORT = "502"
gripper = RG(GRIPPER_NAME, TOOLCHARGER_IP, TOOLCHARGER_PORT)

VELOCITY, ACC = 60, 60


def _resolve_down_name(base: str) -> str:
    base = base.strip()
    if base.startswith("pos"):
        name = base if base.endswith("_down") else f"{base}_down"
    else:
        name = f"pos{base}_down"
    return name


def make_variants(base: str, dz: float, dx: float, dy: float, dx_close: float):
    down_name = _resolve_down_name(base)
    wp_entry = wp.get(down_name)
    if wp_entry is None:
        raise ValueError(f"'{down_name}' 을(를) JSON에서 찾을 수 없습니다.")

    x0, y0, z0, rx, ry, rz = wp_entry["value"]

    poses = {
        "down":        posx([x0,        y0,        z0,        rx, ry, rz]),
        "up":          posx([x0,        y0,        z0 + dz,   rx, ry, rz]),
        "down_x":      posx([x0 + dx,   y0,        z0,        rx, ry, rz]),
        "up_x":        posx([x0 + dx,   y0,        z0 + dz,   rx, ry, rz]),
        "see_pill":    posx([x0 + dx,   y0 + dy,   z0 + dz,   rx, ry, rz]),
        "close_pose":  posx([x0 + dx,   y0 + dy,   z0,        rx, ry, rz]),
        "close":       posx([x0 + dx + dx_close, y0 + dy, z0, rx, ry, rz]),
    }
    return poses


# === 1단계: 픽업 ===
def run_sequence_pick(base, dz, dx, dy, dx_close):
    p = make_variants(base, dz, dx, dy, dx_close)
    movel(p["up"],         vel=VELOCITY, acc=ACC)
    gripper.move_gripper(300)
    movel(p["down"],       vel=VELOCITY, acc=ACC)
    gripper.close_gripper()
    time.sleep(1.0)
    movel(p["down_x"],     vel=VELOCITY, acc=ACC)
    gripper.move_gripper(300)
    time.sleep(1.0)
    movel(p["up_x"],       vel=VELOCITY, acc=ACC)
    movel(p["see_pill"],   vel=VELOCITY, acc=ACC)
    return p


# === 2단계: 배치 ===
def run_sequence_place(base, dz, dx, dy, dx_close):
    p = make_variants(base, dz, dx, dy, dx_close)
    movel(p["close_pose"], vel=VELOCITY, acc=ACC)
    movel(p["close"],      vel=VELOCITY, acc=ACC)
    return p


def current_move(a, b):
    position_list = list(posx(get_current_posx()[0]))
    position_list[a] += b
    modified_position = posx(position_list)
    movel(modified_position, vel=VELOCITY, acc=ACC) 


def drug_info(name: str):
    data = {
        "zaide": {"pos": "4_1", "group": "list_drug"},
        "penzal": {"pos": "4_2", "group": "list_drug"},
        "tg": {"pos": "4_3", "group": "list_drug"},
        "sky": {"pos": "4_4", "group": "list_drug"},
        "famotidine": {"pos": "box_center", "group": "list_box"},
        "somnifacient": {"pos": "box_right", "group": "list_box"},
        "allergy": {"pos": "box_left", "group": "list_box"}
    }
    return data.get(name)


def execute_from_key(base_key: str, step="pick"):
    sequence_params = {
        "4_1": {"dz": 40.0, "dx": -90.0,  "dy": 0,   "dx_close": 105.0},
        "4_2": {"dz": 40.0, "dx": -85.0,  "dy": 0,   "dx_close": 100.0},
        "4_3": {"dz": 40.0, "dx": -90.0, "dy": -50, "dx_close": 105.0},
        "4_4": {"dz": 40.0, "dx": -90.0, "dy": 50,  "dx_close": 105.0},
    }

    if base_key not in sequence_params:
        print(f"[ERROR] {base_key} 는 등록되지 않은 시퀀스입니다.")
        return

    params = sequence_params[base_key]
    if step == "pick":
        run_sequence_pick(base=base_key, **params)
    elif step == "place":
        run_sequence_place(base=base_key, **params)
