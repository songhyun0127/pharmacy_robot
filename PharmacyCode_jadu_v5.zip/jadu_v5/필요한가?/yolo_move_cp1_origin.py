# yolo_test_jsg.py — rqt 실시간 멀티스레드 발행 + 300x300 ROI + 터미널 매칭 + XY 이동(Z 고정)
import os
os.environ["CUDA_VISIBLE_DEVICES"] = ""  # 필요 시 제거

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from rclpy.executors import MultiThreadedExecutor
from sensor_msgs.msg import Image, CameraInfo
from cv_bridge import CvBridge
from ultralytics import YOLO
from scipy.spatial.transform import Rotation
import numpy as np
import threading
from queue import Queue, Empty

import DR_init
from .onrobot import RG

ROBOT_ID = "dsr01"
ROBOT_MODEL = "m0609"
VELOCITY, ACC = 30, 30
DR_init.__dsr__id = ROBOT_ID
DR_init.__dsr__model = ROBOT_MODEL

GRIPPER_NAME = "rg2"
TOOLCHARGER_IP = "192.168.1.1"
TOOLCHARGER_PORT = "502"

YOLO_MODEL_PATH = "/home/jadu/ros2_ws/src/DoosanBootcamp3rd/dsr_rokey/rokey/rokey/basic/my_best_box_3.pt"
T_GRIPPER_PATH = "/home/jadu/ros2_ws/src/DoosanBootcamp3rd/dsr_rokey/rokey/rokey/basic/config/T_gripper2camera.npy"

class TestNode(Node):
    def __init__(self, wp, posx, posj, movej, movel, get_current_posx, wait):
        super().__init__("test_node")
        self.wp = wp
        self.posx = posx
        self.posj = posj
        self.movej = movej
        self.movel = movel
        self.get_current_posx = get_current_posx
        self.wait = wait

        # --- ROS I/O ---
        self.bridge = CvBridge()
        self.pub_vis = self.create_publisher(Image, "/yolo/vis_image", 10)

        
        # self.box_start_sub = self.create_subscription(String, '/box_start', self.box_start_cb, 10)
        self.box_done_pub = self.create_publisher(String, '/box_done', 10)


        self.sub_color = self.create_subscription(Image, "/camera/camera/color/image_raw", self.on_color, 10)
        self.sub_depth = self.create_subscription(Image, "/camera/camera/aligned_depth_to_color/image_raw", self.on_depth, 10)
        self.sub_info  = self.create_subscription(CameraInfo, "/camera/camera/color/camera_info", self.on_info, 10)

        # --- Latest frames / intrinsics ---
        self.depth = None
        self.K = None  # {"fx","fy","ppx","ppy"}

        # --- Robot / Gripper ---
        # 변환 행렬
        self.gripper2cam = np.load(T_GRIPPER_PATH)

        # 준비 자세
        self.JReady = self.posj([0, 0, 90, 0, 90, -90])

        # 그리퍼
        self.gripper = RG(GRIPPER_NAME, TOOLCHARGER_IP, TOOLCHARGER_PORT)

        # --- YOLO ---
        self.model = YOLO(YOLO_MODEL_PATH)
        names = self.model.names
        self.names = names if isinstance(names, dict) else {i:n for i,n in enumerate(names)}
        self.conf_thres = 0.25

        # 추가: 표시용 임계값(바운딩 박스 표시에만 사용)
        self.draw_conf_thres = 0.7

        # --- ROI/State ---
        self.roi_size = 300  # 중앙 300×300
        self.candidates = {}  # {cls_name: (conf,(u,v),(bx1,by1,bx2,by2))}
        self.awaiting_input = False
        self.user_query = None
        self.lock = threading.Lock()

        # --- Publisher thread (실시간 rqt 발행 전용) ---
        self.pub_queue: Queue[tuple] = Queue(maxsize=5)  # (vis_bgr, header)
        self.pub_thread = threading.Thread(target=self._pub_worker, daemon=True)
        self.pub_thread.start()

        # --- Motion thread 상태 ---
        self.moving = False  # 중복 이동 방지

        # --- 입력 스레드 핸들 ---
        self.input_thread = None

    # ===================== topic pub sub ====================

    def box_start_cb(self, msg):
        self.get_logger().info("나 콜백이야 초기화 완료. /box_start 수신 대기 중...")

        self.target_name = msg.data.strip()
        self.box_requested = True
        self.get_logger().info(f"/box_start 수신 - 타겟: {self.target_name}")
        # self.on_color()
        # self._read_user_input_once(self.target_name)
        return self.target_name
    

    def send_done(self):
        done_msg = String()
        done_msg.data = "done"
        self.box_done_pub.publish(done_msg)
        self.get_logger().info("/box_done 발행: done")

    # ===================== Subscriptions =====================
    def on_info(self, msg: CameraInfo):
        self.K = {"fx": msg.k[0], "fy": msg.k[4], "ppx": msg.k[2], "ppy": msg.k[5]}

    def on_depth(self, msg: Image):
        self.depth = self.bridge.imgmsg_to_cv2(msg, desired_encoding="passthrough")

    def on_color(self, msg: Image):
        """새 컬러 프레임마다: YOLO → ROI 300 기억 → 입력 매칭 트리거 → 시각화 큐 적재"""
        if self.depth is None or self.K is None:
            self.get_logger().info("Depth/CameraInfo not yet received, skipping frame.", throttle_duration_sec=5)
            return

        img = self.bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
        if img is None:
            return

        import cv2
        h, w = img.shape[:2]
        cx, cy = w // 2, h // 2
        x1, y1 = max(0, cx - self.roi_size // 2), max(0, cy - self.roi_size // 2)
        x2, y2 = min(w - 1, cx + self.roi_size // 2), min(h - 1, cy + self.roi_size // 2)

        res = self.model.predict(img, verbose=False, device="cpu", conf=self.conf_thres)[0]
        boxes = getattr(res, "boxes", None)

        cand = {}
        if boxes is not None and len(boxes) > 0:
            for i in range(len(boxes)):
                bx1, by1, bx2, by2 = map(int, boxes.xyxy[i].tolist())
                conf = float(boxes.conf[i].item()) if boxes.conf is not None else 0.0
                cls_id = int(boxes.cls[i].item()) if boxes.cls is not None else -1
                cls_name = self.names.get(cls_id, f"id_{cls_id}")
                u = (bx1 + bx2) // 2; v = (by1 + by2) // 2

                if x1 <= u <= x2 and y1 <= v <= y2 and conf >= self.draw_conf_thres:
                    prev = cand.get(cls_name)
                    if (prev is None) or (conf > prev[0]):
                        cand[cls_name] = (conf, (u, v), (bx1, by1, bx2, by2))
                # === 여기부터: 신뢰도 0.7 이상일 때만 박스/라벨/점 표시 ===
                if conf >= self.draw_conf_thres:
                    label = f"{cls_name} {conf*100:.1f}%"
                    cv2.rectangle(img, (bx1, by1), (bx2, by2), (0, 255, 0), 2)
                    (tw, th), bl = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 2)
                    yt = max(by1, th + 4)
                    cv2.rectangle(img, (bx1, yt - th - 4), (bx1 + tw + 4, yt + bl - 2), (0, 255, 0), -1)
                    cv2.putText(img, label, (bx1 + 2, yt - 2), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 0), 2, cv2.LINE_AA)
                    cv2.circle(img, (u, v), 3, (0, 0, 255), -1)
        cv2.rectangle(img, (x1, y1), (x2, y2), (255, 255, 0), 2)

        with self.lock:
            self.candidates = cand

        # 비차단 입력 스레드: 한 번만 대기
        if (not self.awaiting_input) and self.candidates:
            self.awaiting_input = True


            name = self.create_subscription(String, '/box_start', self.box_start_cb, 10)
            self.get_logger().info("나 if야 초기화 완료. /box_start 수신 대기 중...")


            threading.Thread(target=self._read_user_input_once(name), daemon=True).start()

        # 입력이 도착했다면 처리(이동 스레드 트리거)
        with self.lock:
            q = self.user_query
            if q is not None:
                self._try_move_if_match(q)
                self.user_query = None

        # === 발행 전용 스레드로 전달 (실시간) ===
        try:
            if self.pub_queue.full():
                _ = self.pub_queue.get_nowait()  # 가장 오래된 프레임 폐기
            self.pub_queue.put_nowait((img, msg.header))
        except Exception:
            pass
        

    # ===================== Publisher thread =====================
    def _pub_worker(self):
        while rclpy.ok():
            try:
                img, header = self.pub_queue.get(timeout=0.1)
            except Empty:
                continue
            msg_out = self.bridge.cv2_to_imgmsg(img, encoding="bgr8")
            msg_out.header = header
            msg_out.header.frame_id = "yolo_vis"
            self.pub_vis.publish(msg_out)

    # ===================== Non-blocking terminal input =====================
    def _read_user_input_once(self, name):
        try:
            classes_txt = ", ".join(sorted(self.candidates.keys()))
            print(f"[입력대기] ROI(300x300) 감지: {classes_txt}")


            #--------------------edit_by_sg--------------------
            # user_cls = input("[입력] 이동할 클래스명을 입력하세요: ").strip()
            # user_cls = "allergy"
            user_cls = name
            #--------------------edit_by_sg--------------------


        except EOFError:
            user_cls = ""
        with self.lock:
            self.user_query = user_cls
            self.awaiting_input = False

    # ===================== Try motion (in thread) =====================
    def _try_move_if_match(self, user_cls: str):
        if user_cls in self.candidates:
            conf, (u, v), (bx1, by1, bx2, by2) = self.candidates[user_cls]
            u_c = (bx1 + bx2) // 2
            v_c = (by1 + by2) // 2
            if not self.moving:
                self.moving = True
                threading.Thread(target=self._move_xy_thread, args=(u_c, v_c, user_cls), daemon=True).start()
                self.get_logger().info(f"[OK] '{user_cls}' 일치(conf={conf:.3f}) → bbox({u_c},{v_c})로 XY 이동 시작.")
                
            else:
                self.get_logger().info("[SKIP] 이미 이동 중.")
        else:
            self.get_logger().info(f"[NG] '{user_cls}' 미일치. 이동 취소.")

    def _move_xy_thread(self, u, v, user_cls: str):
        try:
            self.move_to_img_xy(u, v, use_gripper=False)
            self._post_move_to_waypoint(user_cls)
        finally:
            self.moving = False
    def _post_move_to_waypoint(self, user_cls: str):
        """
        ROI 기준 XY 이동을 마친 뒤, 사용자 입력 클래스명에 따라
        등록된 웨이포인트로 추가 이동합니다.
        """
        try:
            # 클래스명 → WaypointManager 키 매핑
            cls2wp = {
                'allergy':     'box_left',
                'famotidine':  'box_center',
                'somnifacient':'box_right',
            }
            key = cls2wp.get(user_cls)
            if not key: ## 여기 예외처리는 추후 삭제 가능
                self.get_logger().info(f"[INFO] '{user_cls}'에 대한 웨이포인트 매핑이 없습니다. 추가 이동 생략.")
                return

            target = self.wp.get_pos(key)
            self.get_logger().info(f"[MOVE] 클래스 '{user_cls}' → 웨이포인트 '{key}' 이동 시작.")
            self.movel(target, vel=30, acc=30)
            self.get_logger().info(f"[DONE] 웨이포인트 '{key}' 이동 완료.")

            #--------------------edit_by_sg--------------------
            position_list = list(self.posx(self.get_current_posx()[0]))
            position_list[2] -= 20
            # 수정된 posx 객체 반환
            modified_position = self.posx(position_list)
            self.movel(modified_position, vel=VELOCITY, acc=ACC)



            self.gripper.move_gripper(280)



            position_list = list(self.posx(self.get_current_posx()[0]))
            position_list[2] += 30
            # 수정된 posx 객체 반환
            modified_position = self.posx(position_list)
            self.movel(modified_position, vel=VELOCITY, acc=ACC)
            self.movej(self.JReady, vel=VELOCITY, acc=ACC)
            #--------------------edit_by_sg--------------------

            
            # 박스 위 좌표를 카메라가 로봇본체를 향하도록 / 지금은 반대로 보고 있음 / 홈 좌표 기준으로
        except Exception as e:
            self.get_logger().error(f"[ERR] 웨이포인트 이동 실패: {e}")

            ### 약 상자 집어서 들고 특정 위치로 이동 후 떨구기
            

    # ===================== Kinematics / Motion =====================
    def get_camera_pos(self, u, v, z, K):
        x = (u - K["ppx"]) * z / K["fx"]
        y = (v - K["ppy"]) * z / K["fy"]
        return (x, y, z)

    def get_robot_pose_matrix(self, x, y, z, rx, ry, rz):
        Rm = Rotation.from_euler("ZYZ", [rx, ry, rz], degrees=True).as_matrix()
        T = np.eye(4); T[:3, :3] = Rm; T[:3, 3] = [x, y, z]
        return T

    def cam_to_base(self, Xc):
        base2gripper = self.get_robot_pose_matrix(*self.get_current_posx()[0])
        base2cam = base2gripper @ self.gripper2cam
        Xc_h = np.append(np.array(Xc), 1.0)
        Xb = base2cam @ Xc_h
        return Xb[:3]

    def move_xy_to_base(self, x_b, y_b):
        cur = self.get_current_posx()[0]
        target = self.posx([x_b, y_b, cur[2], cur[3], cur[4], cur[5]])  # Z 유지
        self.movel(target, 30, 30)

    def move_to_img_xy(self, u, v, use_gripper=False):
        if self.depth is None or self.K is None:
            self.get_logger().warn("Depth 또는 CameraInfo 미수신으로 이동 불가.")
            return
        h, w = self.depth.shape
        u = int(np.clip(u, 0, w - 1)); v = int(np.clip(v, 0, h - 1))
        z = float(self.depth[v, u])
        Xc = self.get_camera_pos(u, v, z, self.K)
        Xb = self.cam_to_base(Xc)
        self.move_xy_to_base(Xb[0], Xb[1])
        if use_gripper:
            # self.gripper.close_gripper(); self.wait(1)

            self.send_done()
            # self.movej(self.JReady, 30, 30)
            # self.gripper.open_gripper(); wait(1) #############################################



def main(args=None):
    rclpy.init()
    node = rclpy.create_node("dsr_example_demo_py", namespace=ROBOT_ID)
    DR_init.__dsr__node = node

    from DSR_ROBOT2 import get_current_posx, movej, movel, wait
    from DR_common2 import posx, posj
    try:
        from DSR_ROBOT2 import get_current_posx, movej, movel, wait, mwait
        from DR_common2 import posx, posj
        from .nav_waypoint import WaypointManager
    except ImportError as e:
        print(f"Error importing DSR_ROBOT2 : {e}")
        exit(True)
    wp = WaypointManager("/home/jadu/ros2_ws/src/DoosanBootcamp3rd/dsr_rokey/rokey/rokey/basic/config/waypoint.json")
    see_box = wp.get_pos("see_box")
    movel(see_box, vel=VELOCITY, acc=ACC)
    app = TestNode(wp, posx, posj, movej, movel, get_current_posx, wait)
    try:
        # 멀티스레드 실행기: 콜백 병렬 처리
        executor = MultiThreadedExecutor(num_threads=2)
        executor.add_node(app)
        executor.add_node(node)
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        app.destroy_node()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
   main()