# pip install opencv-python pillow mediapipe
import cv2, os, tkinter as tk, threading, json
from PIL import Image, ImageTk
from urllib import request as urlrequest
import mediapipe as mp
import time

SAVE_DIR = "img_capture_bykey"; os.makedirs(SAVE_DIR, exist_ok=True)
FILE_PREFIX = "web_image_bykey_"

# 서비스 받을 엔드포인트 (예: "http://localhost:8000/hook")
SERVICE_URL = ""  # 비워두면 네트워크 전송 대신 콘솔 출력만 합니다.

# ---- 검출 민감도/속도 파라미터 ----
CHECK_EVERY_N = 2          # N프레임마다 검출(부하 감소)
NEEDED_HITS = 3            # 연속으로 이 횟수만큼 잡히면 전송
DECAY = 1                  # 안 잡히는 프레임에서 감소량
FACE_CONF = 0.4            # 얼굴 검출 신뢰도
POSE_CONF = 0.4            # 포즈 검출 신뢰도
UPPER_VIS_THRESH = 0.5     # 상반신 랜드마크 가시성 기준
RESIZE_SCALE = 0.7         # 검출 속도 위해 입력 축소 배율(0.5~1.0)

class App:
    def __init__(self, root):
        self.root = root
        self.cap = cv2.VideoCapture(0)
        if not self.cap.isOpened():
            raise RuntimeError("웹캠을 열 수 없습니다.")

        # MediaPipe 준비
        self.mp_face = mp.solutions.face_detection
        self.face = self.mp_face.FaceDetection(model_selection=0, min_detection_confidence=FACE_CONF)
        self.mp_pose = mp.solutions.pose
        self.pose = self.mp_pose.Pose(model_complexity=0, min_detection_confidence=POSE_CONF, min_tracking_confidence=POSE_CONF)

        self.label = tk.Label(root, text="영상")
        self.label.pack()
        root.bind("<q>", lambda e: self.cleanup())

        self.frame_idx = 0
        self.hits = 0
        self.service_sent = False

        self.update()

    def detect_face_or_upperbody(self, frame_bgr):
        # 입력 축소 + RGB 변환
        if RESIZE_SCALE != 1.0:
            small = cv2.resize(frame_bgr, (0, 0), fx=RESIZE_SCALE, fy=RESIZE_SCALE)
        else:
            small = frame_bgr
        rgb = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)

        face_boxes = []
        upper_ok = False

        # 얼굴 검출
        f_res = self.face.process(rgb)
        if f_res.detections:
            h, w, _ = small.shape
            for det in f_res.detections:
                bb = det.location_data.relative_bounding_box
                x1 = int(bb.xmin * w); y1 = int(bb.ymin * h)
                x2 = int((bb.xmin + bb.width) * w); y2 = int((bb.ymin + bb.height) * h)
                # 원본 좌표계로 복원
                if RESIZE_SCALE != 1.0:
                    x1 = int(x1 / RESIZE_SCALE); y1 = int(y1 / RESIZE_SCALE)
                    x2 = int(x2 / RESIZE_SCALE); y2 = int(y2 / RESIZE_SCALE)
                face_boxes.append((x1, y1, x2, y2))

        # 상반신(어깨/팔) 포즈 판단
        p_res = self.pose.process(rgb)
        if p_res.pose_landmarks:
            lm = p_res.pose_landmarks.landmark
            # 상반신 관련 랜드마크들
            idxs = [
                self.mp_pose.PoseLandmark.LEFT_SHOULDER,
                self.mp_pose.PoseLandmark.RIGHT_SHOULDER,
                self.mp_pose.PoseLandmark.LEFT_ELBOW,
                self.mp_pose.PoseLandmark.RIGHT_ELBOW,
                self.mp_pose.PoseLandmark.LEFT_WRIST,
                self.mp_pose.PoseLandmark.RIGHT_WRIST,
            ]
            vis_count = sum(1 for i in idxs if lm[i].visibility >= UPPER_VIS_THRESH)
            # 최소 3점 이상 안정적으로 보이면 상반신 있다고 판정
            upper_ok = vis_count >= 3

        detected = (len(face_boxes) > 0) or upper_ok
        return detected, face_boxes, p_res

    def draw_overlays(self, frame_bgr, face_boxes, pose_res):
        # 얼굴 박스
        for (x1, y1, x2, y2) in face_boxes:
            cv2.rectangle(frame_bgr, (x1, y1), (x2, y2), (0, 255, 0), 2)

        # 어깨/팔 포인트 간단히 표시
        if pose_res and pose_res.pose_landmarks:
            h, w, _ = frame_bgr.shape
            lm = pose_res.pose_landmarks.landmark
            pts = [
                self.mp_pose.PoseLandmark.LEFT_SHOULDER,
                self.mp_pose.PoseLandmark.RIGHT_SHOULDER,
                self.mp_pose.PoseLandmark.LEFT_ELBOW,
                self.mp_pose.PoseLandmark.RIGHT_ELBOW,
                self.mp_pose.PoseLandmark.LEFT_WRIST,
                self.mp_pose.PoseLandmark.RIGHT_WRIST,
            ]
            for i in pts:
                x = int(lm[i].x * w); y = int(lm[i].y * h)
                if 0 <= x < w and 0 <= y < h:
                    cv2.circle(frame_bgr, (x, y), 4, (255, 200, 0), -1)

    def send_service(self):
        if self.service_sent:
            return
        self.service_sent = True

        def worker():
            payload = {
                "event": "person_face_or_upperbody_detected",
                "ts": int(time.time() * 1000),
            }
            try:
                if SERVICE_URL:
                    data = json.dumps(payload).encode("utf-8")
                    req = urlrequest.Request(
                        SERVICE_URL, data=data, headers={"Content-Type": "application/json"}
                    )
                    with urlrequest.urlopen(req, timeout=5) as resp:
                        _ = resp.read()
                    print("[서비스] 전송 완료:", payload)
                else:
                    print("[서비스] (드라이런) 전송:", payload)
            except Exception as e:
                print("[서비스] 전송 실패:", e)
            finally:
                self.root.after(400, self.cleanup)

        threading.Thread(target=worker, daemon=True).start()

    def update(self):
        ok, frame = self.cap.read()
        if ok:
            show = frame.copy()

            if not self.service_sent and (self.frame_idx % CHECK_EVERY_N == 0):
                detected, face_boxes, pose_res = self.detect_face_or_upperbody(frame)
                if detected:
                    self.hits += 1
                else:
                    self.hits = max(0, self.hits - DECAY)

                self.draw_overlays(show, face_boxes, pose_res)

                if self.hits >= NEEDED_HITS:
                    cv2.putText(show, "Detected! Sending...", (10, 30),
                                cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 255), 2)
                    self.send_service()
                else:
                    cv2.putText(show, f"Detecting... ({self.hits}/{NEEDED_HITS})", (10, 30),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 2)
            else:
                if self.service_sent:
                    cv2.putText(show, "Service sent. Closing...", (10, 30),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 255), 2)

            rgb = cv2.cvtColor(show, cv2.COLOR_BGR2RGB)
            im = Image.fromarray(rgb)
            imgtk = ImageTk.PhotoImage(image=im)
            self.label.imgtk = imgtk
            self.label.configure(image=imgtk)

            self.frame_idx += 1

        self.root.after(30, self.update)

    def cleanup(self):
        try:
            self.cap.release()
        except Exception:
            pass
        self.root.quit()

if __name__ == "__main__":
    root = tk.Tk()
    root.title("얼굴/상반신 인식 → 서비스 전송")
    app = App(root)
    root.mainloop()
