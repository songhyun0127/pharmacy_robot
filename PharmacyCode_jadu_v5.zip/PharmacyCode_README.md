# 파일 구성 방법

1. 압축 파일을 풀어서 생긴 jadu_v5를 /ros2_ws/src/DoosanBootcamp3rd/dsr_rokey/rokey/rokey 경로에 배치, basic 폴더와 같은 위치에 jadu_v5가 있으면 됨

2. 압축 파일을 풀어서 생긴 config는 /ros2_ws/src/DoosanBootcamp3rd/dsr_rokey/rokey/rokey/basic basic 폴더 안에 넣어두기

3. /ros2_ws/src/DoosanBootcamp3rd/dsr_rokey/rokey 경로의 setup.py의 console_scripts는 아래와 같이 입력

```python
### jadu setting - 250816
            "go_main = rokey.jadu_v5.go_main:main",
            "pill_seg = rokey.jadu_v5.pill_seg:main",
            "box_seg = rokey.jadu_v5.box_seg:main",
            # rokey.jadu_v5로 입력해야 함을 주의
```

4. 터미널을 열어서 로봇 real 모드로 브링업, 다른 터미널에서 카메라 키는 realsense 키고

5. ros2_ws에서 colcon build --packages-select rokey 로 rokey 파일만 콜콘 한 다음에 실행

6. ros2 run rokey go_main 이런 식으로

# 코드 실행 방법

1. 상단의 4, 5가 오류 없이 진행되었다면, 새 터미널을 3개 열기

2. 3개의 터미널 모두 cd ros2_ws 에서 source install/setup.bash 한 이후 go_main, pill_seg, box_seg를 각각 실행

3. go_main에서 터미널 입력으로 알약 이름 혹은 박스 이름을 받으면 구동 시작함
