# generated from rosidl_generator_py/resource/_idl.py.em
# with input from pharmacy_interface:srv/MediCine.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_MediCine_Request(type):
    """Metaclass of message 'MediCine_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('pharmacy_interface')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'pharmacy_interface.srv.MediCine_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__medi_cine__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__medi_cine__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__medi_cine__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__medi_cine__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__medi_cine__request

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class MediCine_Request(metaclass=Metaclass_MediCine_Request):
    """Message class 'MediCine_Request'."""

    __slots__ = [
        '_penzal',
        '_sky',
        '_tg',
        '_zaide',
        '_famotidine',
        '_somnifacient',
        '_allergy',
    ]

    _fields_and_field_types = {
        'penzal': 'boolean',
        'sky': 'boolean',
        'tg': 'boolean',
        'zaide': 'boolean',
        'famotidine': 'boolean',
        'somnifacient': 'boolean',
        'allergy': 'boolean',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.penzal = kwargs.get('penzal', bool())
        self.sky = kwargs.get('sky', bool())
        self.tg = kwargs.get('tg', bool())
        self.zaide = kwargs.get('zaide', bool())
        self.famotidine = kwargs.get('famotidine', bool())
        self.somnifacient = kwargs.get('somnifacient', bool())
        self.allergy = kwargs.get('allergy', bool())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.penzal != other.penzal:
            return False
        if self.sky != other.sky:
            return False
        if self.tg != other.tg:
            return False
        if self.zaide != other.zaide:
            return False
        if self.famotidine != other.famotidine:
            return False
        if self.somnifacient != other.somnifacient:
            return False
        if self.allergy != other.allergy:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def penzal(self):
        """Message field 'penzal'."""
        return self._penzal

    @penzal.setter
    def penzal(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'penzal' field must be of type 'bool'"
        self._penzal = value

    @builtins.property
    def sky(self):
        """Message field 'sky'."""
        return self._sky

    @sky.setter
    def sky(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'sky' field must be of type 'bool'"
        self._sky = value

    @builtins.property
    def tg(self):
        """Message field 'tg'."""
        return self._tg

    @tg.setter
    def tg(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'tg' field must be of type 'bool'"
        self._tg = value

    @builtins.property
    def zaide(self):
        """Message field 'zaide'."""
        return self._zaide

    @zaide.setter
    def zaide(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'zaide' field must be of type 'bool'"
        self._zaide = value

    @builtins.property
    def famotidine(self):
        """Message field 'famotidine'."""
        return self._famotidine

    @famotidine.setter
    def famotidine(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'famotidine' field must be of type 'bool'"
        self._famotidine = value

    @builtins.property
    def somnifacient(self):
        """Message field 'somnifacient'."""
        return self._somnifacient

    @somnifacient.setter
    def somnifacient(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'somnifacient' field must be of type 'bool'"
        self._somnifacient = value

    @builtins.property
    def allergy(self):
        """Message field 'allergy'."""
        return self._allergy

    @allergy.setter
    def allergy(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'allergy' field must be of type 'bool'"
        self._allergy = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_MediCine_Response(type):
    """Metaclass of message 'MediCine_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('pharmacy_interface')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'pharmacy_interface.srv.MediCine_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__medi_cine__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__medi_cine__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__medi_cine__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__medi_cine__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__medi_cine__response

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class MediCine_Response(metaclass=Metaclass_MediCine_Response):
    """Message class 'MediCine_Response'."""

    __slots__ = [
        '_penzal',
        '_sky',
        '_tg',
        '_zaide',
        '_famotidine',
        '_somnifacient',
        '_allergy',
    ]

    _fields_and_field_types = {
        'penzal': 'boolean',
        'sky': 'boolean',
        'tg': 'boolean',
        'zaide': 'boolean',
        'famotidine': 'boolean',
        'somnifacient': 'boolean',
        'allergy': 'boolean',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.penzal = kwargs.get('penzal', bool())
        self.sky = kwargs.get('sky', bool())
        self.tg = kwargs.get('tg', bool())
        self.zaide = kwargs.get('zaide', bool())
        self.famotidine = kwargs.get('famotidine', bool())
        self.somnifacient = kwargs.get('somnifacient', bool())
        self.allergy = kwargs.get('allergy', bool())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.penzal != other.penzal:
            return False
        if self.sky != other.sky:
            return False
        if self.tg != other.tg:
            return False
        if self.zaide != other.zaide:
            return False
        if self.famotidine != other.famotidine:
            return False
        if self.somnifacient != other.somnifacient:
            return False
        if self.allergy != other.allergy:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def penzal(self):
        """Message field 'penzal'."""
        return self._penzal

    @penzal.setter
    def penzal(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'penzal' field must be of type 'bool'"
        self._penzal = value

    @builtins.property
    def sky(self):
        """Message field 'sky'."""
        return self._sky

    @sky.setter
    def sky(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'sky' field must be of type 'bool'"
        self._sky = value

    @builtins.property
    def tg(self):
        """Message field 'tg'."""
        return self._tg

    @tg.setter
    def tg(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'tg' field must be of type 'bool'"
        self._tg = value

    @builtins.property
    def zaide(self):
        """Message field 'zaide'."""
        return self._zaide

    @zaide.setter
    def zaide(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'zaide' field must be of type 'bool'"
        self._zaide = value

    @builtins.property
    def famotidine(self):
        """Message field 'famotidine'."""
        return self._famotidine

    @famotidine.setter
    def famotidine(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'famotidine' field must be of type 'bool'"
        self._famotidine = value

    @builtins.property
    def somnifacient(self):
        """Message field 'somnifacient'."""
        return self._somnifacient

    @somnifacient.setter
    def somnifacient(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'somnifacient' field must be of type 'bool'"
        self._somnifacient = value

    @builtins.property
    def allergy(self):
        """Message field 'allergy'."""
        return self._allergy

    @allergy.setter
    def allergy(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'allergy' field must be of type 'bool'"
        self._allergy = value


class Metaclass_MediCine(type):
    """Metaclass of service 'MediCine'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('pharmacy_interface')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'pharmacy_interface.srv.MediCine')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__medi_cine

            from pharmacy_interface.srv import _medi_cine
            if _medi_cine.Metaclass_MediCine_Request._TYPE_SUPPORT is None:
                _medi_cine.Metaclass_MediCine_Request.__import_type_support__()
            if _medi_cine.Metaclass_MediCine_Response._TYPE_SUPPORT is None:
                _medi_cine.Metaclass_MediCine_Response.__import_type_support__()


class MediCine(metaclass=Metaclass_MediCine):
    from pharmacy_interface.srv._medi_cine import MediCine_Request as Request
    from pharmacy_interface.srv._medi_cine import MediCine_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
