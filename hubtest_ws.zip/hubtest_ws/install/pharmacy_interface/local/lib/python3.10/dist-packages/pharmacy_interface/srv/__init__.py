from pharmacy_interface.srv._medi_cine import MediCine  # noqa: F401
