// generated from rosidl_generator_py/resource/_idl_support.c.em
// with input from pharmacy_interface:srv/MediCine.idl
// generated code does not contain a copyright notice
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <Python.h>
#include <stdbool.h>
#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-function"
#endif
#include "numpy/ndarrayobject.h"
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif
#include "rosidl_runtime_c/visibility_control.h"
#include "pharmacy_interface/srv/detail/medi_cine__struct.h"
#include "pharmacy_interface/srv/detail/medi_cine__functions.h"


ROSIDL_GENERATOR_C_EXPORT
bool pharmacy_interface__srv__medi_cine__request__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[51];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("pharmacy_interface.srv._medi_cine.MediCine_Request", full_classname_dest, 50) == 0);
  }
  pharmacy_interface__srv__MediCine_Request * ros_message = _ros_message;
  {  // penzal
    PyObject * field = PyObject_GetAttrString(_pymsg, "penzal");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->penzal = (Py_True == field);
    Py_DECREF(field);
  }
  {  // sky
    PyObject * field = PyObject_GetAttrString(_pymsg, "sky");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->sky = (Py_True == field);
    Py_DECREF(field);
  }
  {  // tg
    PyObject * field = PyObject_GetAttrString(_pymsg, "tg");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->tg = (Py_True == field);
    Py_DECREF(field);
  }
  {  // zaide
    PyObject * field = PyObject_GetAttrString(_pymsg, "zaide");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->zaide = (Py_True == field);
    Py_DECREF(field);
  }
  {  // famotidine
    PyObject * field = PyObject_GetAttrString(_pymsg, "famotidine");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->famotidine = (Py_True == field);
    Py_DECREF(field);
  }
  {  // somnifacient
    PyObject * field = PyObject_GetAttrString(_pymsg, "somnifacient");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->somnifacient = (Py_True == field);
    Py_DECREF(field);
  }
  {  // allergy
    PyObject * field = PyObject_GetAttrString(_pymsg, "allergy");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->allergy = (Py_True == field);
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * pharmacy_interface__srv__medi_cine__request__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of MediCine_Request */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("pharmacy_interface.srv._medi_cine");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "MediCine_Request");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  pharmacy_interface__srv__MediCine_Request * ros_message = (pharmacy_interface__srv__MediCine_Request *)raw_ros_message;
  {  // penzal
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->penzal ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "penzal", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // sky
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->sky ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "sky", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // tg
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->tg ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "tg", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // zaide
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->zaide ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "zaide", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // famotidine
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->famotidine ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "famotidine", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // somnifacient
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->somnifacient ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "somnifacient", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // allergy
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->allergy ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "allergy", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}

#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
// already included above
// #include <Python.h>
// already included above
// #include <stdbool.h>
// already included above
// #include "numpy/ndarrayobject.h"
// already included above
// #include "rosidl_runtime_c/visibility_control.h"
// already included above
// #include "pharmacy_interface/srv/detail/medi_cine__struct.h"
// already included above
// #include "pharmacy_interface/srv/detail/medi_cine__functions.h"


ROSIDL_GENERATOR_C_EXPORT
bool pharmacy_interface__srv__medi_cine__response__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[52];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("pharmacy_interface.srv._medi_cine.MediCine_Response", full_classname_dest, 51) == 0);
  }
  pharmacy_interface__srv__MediCine_Response * ros_message = _ros_message;
  {  // penzal
    PyObject * field = PyObject_GetAttrString(_pymsg, "penzal");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->penzal = (Py_True == field);
    Py_DECREF(field);
  }
  {  // sky
    PyObject * field = PyObject_GetAttrString(_pymsg, "sky");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->sky = (Py_True == field);
    Py_DECREF(field);
  }
  {  // tg
    PyObject * field = PyObject_GetAttrString(_pymsg, "tg");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->tg = (Py_True == field);
    Py_DECREF(field);
  }
  {  // zaide
    PyObject * field = PyObject_GetAttrString(_pymsg, "zaide");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->zaide = (Py_True == field);
    Py_DECREF(field);
  }
  {  // famotidine
    PyObject * field = PyObject_GetAttrString(_pymsg, "famotidine");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->famotidine = (Py_True == field);
    Py_DECREF(field);
  }
  {  // somnifacient
    PyObject * field = PyObject_GetAttrString(_pymsg, "somnifacient");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->somnifacient = (Py_True == field);
    Py_DECREF(field);
  }
  {  // allergy
    PyObject * field = PyObject_GetAttrString(_pymsg, "allergy");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->allergy = (Py_True == field);
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * pharmacy_interface__srv__medi_cine__response__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of MediCine_Response */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("pharmacy_interface.srv._medi_cine");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "MediCine_Response");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  pharmacy_interface__srv__MediCine_Response * ros_message = (pharmacy_interface__srv__MediCine_Response *)raw_ros_message;
  {  // penzal
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->penzal ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "penzal", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // sky
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->sky ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "sky", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // tg
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->tg ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "tg", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // zaide
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->zaide ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "zaide", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // famotidine
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->famotidine ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "famotidine", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // somnifacient
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->somnifacient ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "somnifacient", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // allergy
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->allergy ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "allergy", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}
