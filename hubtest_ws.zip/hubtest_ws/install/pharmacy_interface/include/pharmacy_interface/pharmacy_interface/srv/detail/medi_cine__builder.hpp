// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from pharmacy_interface:srv/MediCine.idl
// generated code does not contain a copyright notice

#ifndef PHARMACY_INTERFACE__SRV__DETAIL__MEDI_CINE__BUILDER_HPP_
#define PHARMACY_INTERFACE__SRV__DETAIL__MEDI_CINE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "pharmacy_interface/srv/detail/medi_cine__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace pharmacy_interface
{

namespace srv
{

namespace builder
{

class Init_MediCine_Request_allergy
{
public:
  explicit Init_MediCine_Request_allergy(::pharmacy_interface::srv::MediCine_Request & msg)
  : msg_(msg)
  {}
  ::pharmacy_interface::srv::MediCine_Request allergy(::pharmacy_interface::srv::MediCine_Request::_allergy_type arg)
  {
    msg_.allergy = std::move(arg);
    return std::move(msg_);
  }

private:
  ::pharmacy_interface::srv::MediCine_Request msg_;
};

class Init_MediCine_Request_somnifacient
{
public:
  explicit Init_MediCine_Request_somnifacient(::pharmacy_interface::srv::MediCine_Request & msg)
  : msg_(msg)
  {}
  Init_MediCine_Request_allergy somnifacient(::pharmacy_interface::srv::MediCine_Request::_somnifacient_type arg)
  {
    msg_.somnifacient = std::move(arg);
    return Init_MediCine_Request_allergy(msg_);
  }

private:
  ::pharmacy_interface::srv::MediCine_Request msg_;
};

class Init_MediCine_Request_famotidine
{
public:
  explicit Init_MediCine_Request_famotidine(::pharmacy_interface::srv::MediCine_Request & msg)
  : msg_(msg)
  {}
  Init_MediCine_Request_somnifacient famotidine(::pharmacy_interface::srv::MediCine_Request::_famotidine_type arg)
  {
    msg_.famotidine = std::move(arg);
    return Init_MediCine_Request_somnifacient(msg_);
  }

private:
  ::pharmacy_interface::srv::MediCine_Request msg_;
};

class Init_MediCine_Request_zaide
{
public:
  explicit Init_MediCine_Request_zaide(::pharmacy_interface::srv::MediCine_Request & msg)
  : msg_(msg)
  {}
  Init_MediCine_Request_famotidine zaide(::pharmacy_interface::srv::MediCine_Request::_zaide_type arg)
  {
    msg_.zaide = std::move(arg);
    return Init_MediCine_Request_famotidine(msg_);
  }

private:
  ::pharmacy_interface::srv::MediCine_Request msg_;
};

class Init_MediCine_Request_tg
{
public:
  explicit Init_MediCine_Request_tg(::pharmacy_interface::srv::MediCine_Request & msg)
  : msg_(msg)
  {}
  Init_MediCine_Request_zaide tg(::pharmacy_interface::srv::MediCine_Request::_tg_type arg)
  {
    msg_.tg = std::move(arg);
    return Init_MediCine_Request_zaide(msg_);
  }

private:
  ::pharmacy_interface::srv::MediCine_Request msg_;
};

class Init_MediCine_Request_sky
{
public:
  explicit Init_MediCine_Request_sky(::pharmacy_interface::srv::MediCine_Request & msg)
  : msg_(msg)
  {}
  Init_MediCine_Request_tg sky(::pharmacy_interface::srv::MediCine_Request::_sky_type arg)
  {
    msg_.sky = std::move(arg);
    return Init_MediCine_Request_tg(msg_);
  }

private:
  ::pharmacy_interface::srv::MediCine_Request msg_;
};

class Init_MediCine_Request_penzal
{
public:
  Init_MediCine_Request_penzal()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MediCine_Request_sky penzal(::pharmacy_interface::srv::MediCine_Request::_penzal_type arg)
  {
    msg_.penzal = std::move(arg);
    return Init_MediCine_Request_sky(msg_);
  }

private:
  ::pharmacy_interface::srv::MediCine_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::pharmacy_interface::srv::MediCine_Request>()
{
  return pharmacy_interface::srv::builder::Init_MediCine_Request_penzal();
}

}  // namespace pharmacy_interface


namespace pharmacy_interface
{

namespace srv
{

namespace builder
{

class Init_MediCine_Response_allergy
{
public:
  explicit Init_MediCine_Response_allergy(::pharmacy_interface::srv::MediCine_Response & msg)
  : msg_(msg)
  {}
  ::pharmacy_interface::srv::MediCine_Response allergy(::pharmacy_interface::srv::MediCine_Response::_allergy_type arg)
  {
    msg_.allergy = std::move(arg);
    return std::move(msg_);
  }

private:
  ::pharmacy_interface::srv::MediCine_Response msg_;
};

class Init_MediCine_Response_somnifacient
{
public:
  explicit Init_MediCine_Response_somnifacient(::pharmacy_interface::srv::MediCine_Response & msg)
  : msg_(msg)
  {}
  Init_MediCine_Response_allergy somnifacient(::pharmacy_interface::srv::MediCine_Response::_somnifacient_type arg)
  {
    msg_.somnifacient = std::move(arg);
    return Init_MediCine_Response_allergy(msg_);
  }

private:
  ::pharmacy_interface::srv::MediCine_Response msg_;
};

class Init_MediCine_Response_famotidine
{
public:
  explicit Init_MediCine_Response_famotidine(::pharmacy_interface::srv::MediCine_Response & msg)
  : msg_(msg)
  {}
  Init_MediCine_Response_somnifacient famotidine(::pharmacy_interface::srv::MediCine_Response::_famotidine_type arg)
  {
    msg_.famotidine = std::move(arg);
    return Init_MediCine_Response_somnifacient(msg_);
  }

private:
  ::pharmacy_interface::srv::MediCine_Response msg_;
};

class Init_MediCine_Response_zaide
{
public:
  explicit Init_MediCine_Response_zaide(::pharmacy_interface::srv::MediCine_Response & msg)
  : msg_(msg)
  {}
  Init_MediCine_Response_famotidine zaide(::pharmacy_interface::srv::MediCine_Response::_zaide_type arg)
  {
    msg_.zaide = std::move(arg);
    return Init_MediCine_Response_famotidine(msg_);
  }

private:
  ::pharmacy_interface::srv::MediCine_Response msg_;
};

class Init_MediCine_Response_tg
{
public:
  explicit Init_MediCine_Response_tg(::pharmacy_interface::srv::MediCine_Response & msg)
  : msg_(msg)
  {}
  Init_MediCine_Response_zaide tg(::pharmacy_interface::srv::MediCine_Response::_tg_type arg)
  {
    msg_.tg = std::move(arg);
    return Init_MediCine_Response_zaide(msg_);
  }

private:
  ::pharmacy_interface::srv::MediCine_Response msg_;
};

class Init_MediCine_Response_sky
{
public:
  explicit Init_MediCine_Response_sky(::pharmacy_interface::srv::MediCine_Response & msg)
  : msg_(msg)
  {}
  Init_MediCine_Response_tg sky(::pharmacy_interface::srv::MediCine_Response::_sky_type arg)
  {
    msg_.sky = std::move(arg);
    return Init_MediCine_Response_tg(msg_);
  }

private:
  ::pharmacy_interface::srv::MediCine_Response msg_;
};

class Init_MediCine_Response_penzal
{
public:
  Init_MediCine_Response_penzal()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MediCine_Response_sky penzal(::pharmacy_interface::srv::MediCine_Response::_penzal_type arg)
  {
    msg_.penzal = std::move(arg);
    return Init_MediCine_Response_sky(msg_);
  }

private:
  ::pharmacy_interface::srv::MediCine_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::pharmacy_interface::srv::MediCine_Response>()
{
  return pharmacy_interface::srv::builder::Init_MediCine_Response_penzal();
}

}  // namespace pharmacy_interface

#endif  // PHARMACY_INTERFACE__SRV__DETAIL__MEDI_CINE__BUILDER_HPP_
