// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from pharmacy_interface:srv/MediCine.idl
// generated code does not contain a copyright notice

#ifndef PHARMACY_INTERFACE__SRV__DETAIL__MEDI_CINE__TRAITS_HPP_
#define PHARMACY_INTERFACE__SRV__DETAIL__MEDI_CINE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "pharmacy_interface/srv/detail/medi_cine__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace pharmacy_interface
{

namespace srv
{

inline void to_flow_style_yaml(
  const MediCine_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: penzal
  {
    out << "penzal: ";
    rosidl_generator_traits::value_to_yaml(msg.penzal, out);
    out << ", ";
  }

  // member: sky
  {
    out << "sky: ";
    rosidl_generator_traits::value_to_yaml(msg.sky, out);
    out << ", ";
  }

  // member: tg
  {
    out << "tg: ";
    rosidl_generator_traits::value_to_yaml(msg.tg, out);
    out << ", ";
  }

  // member: zaide
  {
    out << "zaide: ";
    rosidl_generator_traits::value_to_yaml(msg.zaide, out);
    out << ", ";
  }

  // member: famotidine
  {
    out << "famotidine: ";
    rosidl_generator_traits::value_to_yaml(msg.famotidine, out);
    out << ", ";
  }

  // member: somnifacient
  {
    out << "somnifacient: ";
    rosidl_generator_traits::value_to_yaml(msg.somnifacient, out);
    out << ", ";
  }

  // member: allergy
  {
    out << "allergy: ";
    rosidl_generator_traits::value_to_yaml(msg.allergy, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MediCine_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: penzal
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "penzal: ";
    rosidl_generator_traits::value_to_yaml(msg.penzal, out);
    out << "\n";
  }

  // member: sky
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sky: ";
    rosidl_generator_traits::value_to_yaml(msg.sky, out);
    out << "\n";
  }

  // member: tg
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "tg: ";
    rosidl_generator_traits::value_to_yaml(msg.tg, out);
    out << "\n";
  }

  // member: zaide
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "zaide: ";
    rosidl_generator_traits::value_to_yaml(msg.zaide, out);
    out << "\n";
  }

  // member: famotidine
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "famotidine: ";
    rosidl_generator_traits::value_to_yaml(msg.famotidine, out);
    out << "\n";
  }

  // member: somnifacient
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "somnifacient: ";
    rosidl_generator_traits::value_to_yaml(msg.somnifacient, out);
    out << "\n";
  }

  // member: allergy
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "allergy: ";
    rosidl_generator_traits::value_to_yaml(msg.allergy, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MediCine_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace pharmacy_interface

namespace rosidl_generator_traits
{

[[deprecated("use pharmacy_interface::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const pharmacy_interface::srv::MediCine_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  pharmacy_interface::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use pharmacy_interface::srv::to_yaml() instead")]]
inline std::string to_yaml(const pharmacy_interface::srv::MediCine_Request & msg)
{
  return pharmacy_interface::srv::to_yaml(msg);
}

template<>
inline const char * data_type<pharmacy_interface::srv::MediCine_Request>()
{
  return "pharmacy_interface::srv::MediCine_Request";
}

template<>
inline const char * name<pharmacy_interface::srv::MediCine_Request>()
{
  return "pharmacy_interface/srv/MediCine_Request";
}

template<>
struct has_fixed_size<pharmacy_interface::srv::MediCine_Request>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<pharmacy_interface::srv::MediCine_Request>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<pharmacy_interface::srv::MediCine_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace pharmacy_interface
{

namespace srv
{

inline void to_flow_style_yaml(
  const MediCine_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: penzal
  {
    out << "penzal: ";
    rosidl_generator_traits::value_to_yaml(msg.penzal, out);
    out << ", ";
  }

  // member: sky
  {
    out << "sky: ";
    rosidl_generator_traits::value_to_yaml(msg.sky, out);
    out << ", ";
  }

  // member: tg
  {
    out << "tg: ";
    rosidl_generator_traits::value_to_yaml(msg.tg, out);
    out << ", ";
  }

  // member: zaide
  {
    out << "zaide: ";
    rosidl_generator_traits::value_to_yaml(msg.zaide, out);
    out << ", ";
  }

  // member: famotidine
  {
    out << "famotidine: ";
    rosidl_generator_traits::value_to_yaml(msg.famotidine, out);
    out << ", ";
  }

  // member: somnifacient
  {
    out << "somnifacient: ";
    rosidl_generator_traits::value_to_yaml(msg.somnifacient, out);
    out << ", ";
  }

  // member: allergy
  {
    out << "allergy: ";
    rosidl_generator_traits::value_to_yaml(msg.allergy, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MediCine_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: penzal
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "penzal: ";
    rosidl_generator_traits::value_to_yaml(msg.penzal, out);
    out << "\n";
  }

  // member: sky
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sky: ";
    rosidl_generator_traits::value_to_yaml(msg.sky, out);
    out << "\n";
  }

  // member: tg
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "tg: ";
    rosidl_generator_traits::value_to_yaml(msg.tg, out);
    out << "\n";
  }

  // member: zaide
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "zaide: ";
    rosidl_generator_traits::value_to_yaml(msg.zaide, out);
    out << "\n";
  }

  // member: famotidine
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "famotidine: ";
    rosidl_generator_traits::value_to_yaml(msg.famotidine, out);
    out << "\n";
  }

  // member: somnifacient
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "somnifacient: ";
    rosidl_generator_traits::value_to_yaml(msg.somnifacient, out);
    out << "\n";
  }

  // member: allergy
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "allergy: ";
    rosidl_generator_traits::value_to_yaml(msg.allergy, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MediCine_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace pharmacy_interface

namespace rosidl_generator_traits
{

[[deprecated("use pharmacy_interface::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const pharmacy_interface::srv::MediCine_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  pharmacy_interface::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use pharmacy_interface::srv::to_yaml() instead")]]
inline std::string to_yaml(const pharmacy_interface::srv::MediCine_Response & msg)
{
  return pharmacy_interface::srv::to_yaml(msg);
}

template<>
inline const char * data_type<pharmacy_interface::srv::MediCine_Response>()
{
  return "pharmacy_interface::srv::MediCine_Response";
}

template<>
inline const char * name<pharmacy_interface::srv::MediCine_Response>()
{
  return "pharmacy_interface/srv/MediCine_Response";
}

template<>
struct has_fixed_size<pharmacy_interface::srv::MediCine_Response>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<pharmacy_interface::srv::MediCine_Response>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<pharmacy_interface::srv::MediCine_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<pharmacy_interface::srv::MediCine>()
{
  return "pharmacy_interface::srv::MediCine";
}

template<>
inline const char * name<pharmacy_interface::srv::MediCine>()
{
  return "pharmacy_interface/srv/MediCine";
}

template<>
struct has_fixed_size<pharmacy_interface::srv::MediCine>
  : std::integral_constant<
    bool,
    has_fixed_size<pharmacy_interface::srv::MediCine_Request>::value &&
    has_fixed_size<pharmacy_interface::srv::MediCine_Response>::value
  >
{
};

template<>
struct has_bounded_size<pharmacy_interface::srv::MediCine>
  : std::integral_constant<
    bool,
    has_bounded_size<pharmacy_interface::srv::MediCine_Request>::value &&
    has_bounded_size<pharmacy_interface::srv::MediCine_Response>::value
  >
{
};

template<>
struct is_service<pharmacy_interface::srv::MediCine>
  : std::true_type
{
};

template<>
struct is_service_request<pharmacy_interface::srv::MediCine_Request>
  : std::true_type
{
};

template<>
struct is_service_response<pharmacy_interface::srv::MediCine_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // PHARMACY_INTERFACE__SRV__DETAIL__MEDI_CINE__TRAITS_HPP_
