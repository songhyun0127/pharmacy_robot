// generated from rosidl_generator_c/resource/idl.h.em
// with input from pharmacy_interface:srv/MediCine.idl
// generated code does not contain a copyright notice

#ifndef PHARMACY_INTERFACE__SRV__MEDI_CINE_H_
#define PHARMACY_INTERFACE__SRV__MEDI_CINE_H_

#include "pharmacy_interface/srv/detail/medi_cine__struct.h"
#include "pharmacy_interface/srv/detail/medi_cine__functions.h"
#include "pharmacy_interface/srv/detail/medi_cine__type_support.h"

#endif  // PHARMACY_INTERFACE__SRV__MEDI_CINE_H_
