// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from pharmacy_interface:srv/MediCine.idl
// generated code does not contain a copyright notice

#ifndef PHARMACY_INTERFACE__SRV__DETAIL__MEDI_CINE__STRUCT_HPP_
#define PHARMACY_INTERFACE__SRV__DETAIL__MEDI_CINE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__pharmacy_interface__srv__MediCine_Request __attribute__((deprecated))
#else
# define DEPRECATED__pharmacy_interface__srv__MediCine_Request __declspec(deprecated)
#endif

namespace pharmacy_interface
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct MediCine_Request_
{
  using Type = MediCine_Request_<ContainerAllocator>;

  explicit MediCine_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->penzal = false;
      this->sky = false;
      this->tg = false;
      this->zaide = false;
      this->famotidine = false;
      this->somnifacient = false;
      this->allergy = false;
    }
  }

  explicit MediCine_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->penzal = false;
      this->sky = false;
      this->tg = false;
      this->zaide = false;
      this->famotidine = false;
      this->somnifacient = false;
      this->allergy = false;
    }
  }

  // field types and members
  using _penzal_type =
    bool;
  _penzal_type penzal;
  using _sky_type =
    bool;
  _sky_type sky;
  using _tg_type =
    bool;
  _tg_type tg;
  using _zaide_type =
    bool;
  _zaide_type zaide;
  using _famotidine_type =
    bool;
  _famotidine_type famotidine;
  using _somnifacient_type =
    bool;
  _somnifacient_type somnifacient;
  using _allergy_type =
    bool;
  _allergy_type allergy;

  // setters for named parameter idiom
  Type & set__penzal(
    const bool & _arg)
  {
    this->penzal = _arg;
    return *this;
  }
  Type & set__sky(
    const bool & _arg)
  {
    this->sky = _arg;
    return *this;
  }
  Type & set__tg(
    const bool & _arg)
  {
    this->tg = _arg;
    return *this;
  }
  Type & set__zaide(
    const bool & _arg)
  {
    this->zaide = _arg;
    return *this;
  }
  Type & set__famotidine(
    const bool & _arg)
  {
    this->famotidine = _arg;
    return *this;
  }
  Type & set__somnifacient(
    const bool & _arg)
  {
    this->somnifacient = _arg;
    return *this;
  }
  Type & set__allergy(
    const bool & _arg)
  {
    this->allergy = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    pharmacy_interface::srv::MediCine_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const pharmacy_interface::srv::MediCine_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<pharmacy_interface::srv::MediCine_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<pharmacy_interface::srv::MediCine_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      pharmacy_interface::srv::MediCine_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<pharmacy_interface::srv::MediCine_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      pharmacy_interface::srv::MediCine_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<pharmacy_interface::srv::MediCine_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<pharmacy_interface::srv::MediCine_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<pharmacy_interface::srv::MediCine_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__pharmacy_interface__srv__MediCine_Request
    std::shared_ptr<pharmacy_interface::srv::MediCine_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__pharmacy_interface__srv__MediCine_Request
    std::shared_ptr<pharmacy_interface::srv::MediCine_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const MediCine_Request_ & other) const
  {
    if (this->penzal != other.penzal) {
      return false;
    }
    if (this->sky != other.sky) {
      return false;
    }
    if (this->tg != other.tg) {
      return false;
    }
    if (this->zaide != other.zaide) {
      return false;
    }
    if (this->famotidine != other.famotidine) {
      return false;
    }
    if (this->somnifacient != other.somnifacient) {
      return false;
    }
    if (this->allergy != other.allergy) {
      return false;
    }
    return true;
  }
  bool operator!=(const MediCine_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct MediCine_Request_

// alias to use template instance with default allocator
using MediCine_Request =
  pharmacy_interface::srv::MediCine_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace pharmacy_interface


#ifndef _WIN32
# define DEPRECATED__pharmacy_interface__srv__MediCine_Response __attribute__((deprecated))
#else
# define DEPRECATED__pharmacy_interface__srv__MediCine_Response __declspec(deprecated)
#endif

namespace pharmacy_interface
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct MediCine_Response_
{
  using Type = MediCine_Response_<ContainerAllocator>;

  explicit MediCine_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->penzal = false;
      this->sky = false;
      this->tg = false;
      this->zaide = false;
      this->famotidine = false;
      this->somnifacient = false;
      this->allergy = false;
    }
  }

  explicit MediCine_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->penzal = false;
      this->sky = false;
      this->tg = false;
      this->zaide = false;
      this->famotidine = false;
      this->somnifacient = false;
      this->allergy = false;
    }
  }

  // field types and members
  using _penzal_type =
    bool;
  _penzal_type penzal;
  using _sky_type =
    bool;
  _sky_type sky;
  using _tg_type =
    bool;
  _tg_type tg;
  using _zaide_type =
    bool;
  _zaide_type zaide;
  using _famotidine_type =
    bool;
  _famotidine_type famotidine;
  using _somnifacient_type =
    bool;
  _somnifacient_type somnifacient;
  using _allergy_type =
    bool;
  _allergy_type allergy;

  // setters for named parameter idiom
  Type & set__penzal(
    const bool & _arg)
  {
    this->penzal = _arg;
    return *this;
  }
  Type & set__sky(
    const bool & _arg)
  {
    this->sky = _arg;
    return *this;
  }
  Type & set__tg(
    const bool & _arg)
  {
    this->tg = _arg;
    return *this;
  }
  Type & set__zaide(
    const bool & _arg)
  {
    this->zaide = _arg;
    return *this;
  }
  Type & set__famotidine(
    const bool & _arg)
  {
    this->famotidine = _arg;
    return *this;
  }
  Type & set__somnifacient(
    const bool & _arg)
  {
    this->somnifacient = _arg;
    return *this;
  }
  Type & set__allergy(
    const bool & _arg)
  {
    this->allergy = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    pharmacy_interface::srv::MediCine_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const pharmacy_interface::srv::MediCine_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<pharmacy_interface::srv::MediCine_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<pharmacy_interface::srv::MediCine_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      pharmacy_interface::srv::MediCine_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<pharmacy_interface::srv::MediCine_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      pharmacy_interface::srv::MediCine_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<pharmacy_interface::srv::MediCine_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<pharmacy_interface::srv::MediCine_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<pharmacy_interface::srv::MediCine_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__pharmacy_interface__srv__MediCine_Response
    std::shared_ptr<pharmacy_interface::srv::MediCine_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__pharmacy_interface__srv__MediCine_Response
    std::shared_ptr<pharmacy_interface::srv::MediCine_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const MediCine_Response_ & other) const
  {
    if (this->penzal != other.penzal) {
      return false;
    }
    if (this->sky != other.sky) {
      return false;
    }
    if (this->tg != other.tg) {
      return false;
    }
    if (this->zaide != other.zaide) {
      return false;
    }
    if (this->famotidine != other.famotidine) {
      return false;
    }
    if (this->somnifacient != other.somnifacient) {
      return false;
    }
    if (this->allergy != other.allergy) {
      return false;
    }
    return true;
  }
  bool operator!=(const MediCine_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct MediCine_Response_

// alias to use template instance with default allocator
using MediCine_Response =
  pharmacy_interface::srv::MediCine_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace pharmacy_interface

namespace pharmacy_interface
{

namespace srv
{

struct MediCine
{
  using Request = pharmacy_interface::srv::MediCine_Request;
  using Response = pharmacy_interface::srv::MediCine_Response;
};

}  // namespace srv

}  // namespace pharmacy_interface

#endif  // PHARMACY_INTERFACE__SRV__DETAIL__MEDI_CINE__STRUCT_HPP_
