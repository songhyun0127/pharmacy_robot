// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from pharmacy_interface:srv/MediCine.idl
// generated code does not contain a copyright notice

#ifndef PHARMACY_INTERFACE__SRV__DETAIL__MEDI_CINE__STRUCT_H_
#define PHARMACY_INTERFACE__SRV__DETAIL__MEDI_CINE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in srv/MediCine in the package pharmacy_interface.
typedef struct pharmacy_interface__srv__MediCine_Request
{
  bool penzal;
  bool sky;
  bool tg;
  bool zaide;
  bool famotidine;
  bool somnifacient;
  bool allergy;
} pharmacy_interface__srv__MediCine_Request;

// Struct for a sequence of pharmacy_interface__srv__MediCine_Request.
typedef struct pharmacy_interface__srv__MediCine_Request__Sequence
{
  pharmacy_interface__srv__MediCine_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} pharmacy_interface__srv__MediCine_Request__Sequence;


// Constants defined in the message

/// Struct defined in srv/MediCine in the package pharmacy_interface.
typedef struct pharmacy_interface__srv__MediCine_Response
{
  bool penzal;
  bool sky;
  bool tg;
  bool zaide;
  bool famotidine;
  bool somnifacient;
  bool allergy;
} pharmacy_interface__srv__MediCine_Response;

// Struct for a sequence of pharmacy_interface__srv__MediCine_Response.
typedef struct pharmacy_interface__srv__MediCine_Response__Sequence
{
  pharmacy_interface__srv__MediCine_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} pharmacy_interface__srv__MediCine_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // PHARMACY_INTERFACE__SRV__DETAIL__MEDI_CINE__STRUCT_H_
