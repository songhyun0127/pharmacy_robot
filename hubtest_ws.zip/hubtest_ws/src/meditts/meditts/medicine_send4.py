import os
import sys
import json
import subprocess
import rclpy
from rclpy.node import Node
from pharmacy_interface.srv import MediCine

class MedicineSenderNode(Node):
    def __init__(self):
        super().__init__('medicine_sender_node')
        self.client = self.create_client(MediCine, 'order_medicines')
        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('서비스 서버를 기다리는 중...')
        self.get_logger().info('서비스 서버에 연결되었습니다.')

    def run_main_script_and_send_order(self):
        # '일꾼' 스크립트의 경로를 지정합니다.
        script_path = os.path.join(os.path.dirname(__file__), 'STT_QR_connect.py')
        
        self.get_logger().info(f"'{script_path}' 스크립트 실행 중...")
        try:
            subprocess.run([sys.executable, script_path], check=True)
            self.get_logger().info("스크립트 실행 완료.")
        except subprocess.CalledProcessError as e:
            self.get_logger().error(f"스크립트가 오류와 함께 종료되었습니다: {e}")
            return

        # ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ [핵심 수정 부분] ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
        # 사용자가 요청한 특정 경로에서 결과 파일을 찾습니다.
        target_dir = os.path.expanduser("~") 
        json_path = os.path.join(target_dir, "decision.json")
        # ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲
        
        if not os.path.exists(json_path):
            self.get_logger().warn(f"'{json_path}' 파일이 생성되지 않았습니다.")
            return

        self.get_logger().info(f"'{json_path}' 파일 읽는 중...")
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                medicine_data = json.load(f)
        except Exception as e:
            self.get_logger().error(f"JSON 파일 읽기 실패: {e}")
            return

        # 서비스 요청 메시지를 생성하고 보냅니다.
        request = MediCine.Request()
        request.penzal = medicine_data.get('penzal', False)
        request.sky = medicine_data.get('sky', False)
        request.tg = medicine_data.get('tg', False)
        request.zaide = medicine_data.get('zaide', False)
        request.famotidine = medicine_data.get('famotidine', False)
        request.somnifacient = medicine_data.get('somnifacient', False)
        request.allergy = medicine_data.get('allergy', False)
        
        self.get_logger().info("서비스 요청 전송 중...")
        future = self.client.call_async(request)
        rclpy.spin_until_future_complete(self, future)
        
        try:
            response = future.result()
            self.get_logger().info(f"서버 응답: {response}")
        except Exception as e:
            self.get_logger().error(f'서비스 요청 중 예외 발생: {e}')
        
        # 파일 삭제는 비활성화된 상태입니다.
        # os.remove(json_path)
        self.get_logger().info(f"'{json_path}' 파일을 삭제하지 않고 유지합니다.")


def main(args=None):
    rclpy.init(args=args)
    node = MedicineSenderNode()
    node.run_main_script_and_send_order()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()